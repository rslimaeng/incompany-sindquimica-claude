# CLAUDE.md · Pagamento de fornecedores · Química Serra Azul

> Empresa fictícia, material de curso. Este arquivo é lido toda vez que uma conversa abre nesta pasta.
> **Ao entrar, leia também o `00-aqui-paramos.md`** (onde paramos) e as skills em `.claude/skills/`.

## A dor

Todo mês, a coordenação de suprimentos cruza, lote a lote, a **nota fiscal**, o **pedido de compra** e o **laudo do lote** de 5 fornecedores antes de liberar o pagamento. Os arquivos chegam por e-mail, cada fornecedor num formato. Quem **libera** é a coordenação de suprimentos (o usuário desta pasta); quem **paga** é o financeiro, e é ele quem usa o resultado.

## A frase que atualiza tudo

Quando chegarem os arquivos do mês seguinte, o usuário diz: **"leia os novos arquivos"**.
Siga a skill **`atualizar-painel`** (`.claude/skills/atualizar-painel/SKILL.md`). Em resumo: os arquivos já estão em `novos-arquivos/` (notas e laudos dos 5 fornecedores, **e as vendas e as despesas do período**); rode `python3 programa/atualizar.py`; confira; conte o que entrou e o que pede decisão; **e termine atualizando o `00-aqui-paramos.md`**. Vendas e despesas entram pela mesma frase.

> **Toda atualização termina atualizando o `00-aqui-paramos.md`.** Sem isso, a atualização não acabou.

## As regras (decididas pelo usuário)

1. **Preço.** Até 2 % acima do preço do pedido: paga a nota. Acima de 2 %: paga o **preço do pedido**, e a diferença vira **cobrança ao fornecedor**.
2. **Quantidade.** Paga o que o almoxarifado **recebeu** (coluna "Qtd recebida" do pedido). O que veio faturado a mais vira cobrança.
3. **Qualidade.** Lote fora da especificação, sem especificação cadastrada ou sem laudo: o pagamento fica **retido** até a qualidade decidir. O limite da especificação conta como dentro. "<0,05" é conforme.
4. **Nota repetida.** Paga uma vez só. A repetição não entra no faturado.
5. **Nota sem pedido.** **Bloqueada** até suprimentos confirmar.

### Como o programa aplica as regras (decisões do assistente, para o usuário conferir)

Isto não estava escrito nas respostas do usuário; foi decidido e fica registrado aqui. **Mudar qualquer uma é decisão do usuário.**

- **Período** de uma nota = a **data de emissão** da nota, não a aba nem o arquivo em que ela veio.
- **Nota repetida** = mesmo fornecedor e mesmo número de nota. A primeira vale; as outras são listadas como repetidas (no painel, em *Conferência*) e **não entram**.
- **Nota e pedido** se ligam pelo **lote** (todo fornecedor informa o lote). O número de pedido que a nota cita só é conferido contra isso. Cada fornecedor escreve o pedido de um jeito ("PC 2026-0003", "0001", "ref. pedido PC-2026-0002", ou nada: a Carnaúba não cita pedido).
- **Unidades:** toneladas viram kg; ppm e mg/kg são a mesma coisa. Texto como "R$ 14.800,00" ou "9,82" vira número. Parâmetros de laudo são comparados com a especificação pelo nome.
- **Qualidade:** o veredito é do **nosso** cruzamento laudo × `cadastros/especificacoes-materia-prima.xlsx`, **não** o "Aprovado"/"Conforme" que o fornecedor escreve no laudo. Laudo sem um dos parâmetros da especificação também fica retido.
- **Cada nota tem uma situação só**, e o valor dela se divide sem sobra:
  `faturado = liberado + retido + bloqueado + cobrado a mais`
  - **Liberado**: valor a pagar de nota sem pendência de pedido nem de qualidade.
  - **Retido**: valor a pagar de nota com problema de qualidade (espera a qualidade).
  - **Bloqueado**: valor inteiro de nota sem pedido (espera suprimentos).
  - **Cobrado a mais**: o que a nota cobra acima do que se paga (preço acima de 2 % ou quantidade acima da recebida). Vira cobrança ao fornecedor **mesmo quando a nota está retida**.
- **Valor a pagar** = o menor entre quantidade faturada e recebida × preço pago (o da nota, se até 2 % acima; senão o do pedido).

## O que o resultado mostra

O **`painel.html`**, no padrão visual da empresa, abre com dois cliques, **sem internet e sem servidor** (o logo e as fotos estão dentro do arquivo):

- **menu lateral** e **seletor de período**: janeiro a dezembro de 2026, por **mês**, **trimestre** ou **ano**;
- os **números grandes do período**: faturado, liberado para pagar, retido, bloqueado e cobrado a mais (clicar abre a lista que os forma);
- **gráficos** (SVG), **tabelas com busca** e ordenação, e **"O que fazer"**: a lista, nota por nota, do que decidir;
- **uma página por fornecedor**, com o logo e a foto dele (da pasta `fornecedores`);
- **Comparar fornecedores**: quem concentra o gasto e quem dá mais pendência;
- **Conferência**: o total da tela contra o total dos arquivos.
- **Diretoria** (3 páginas, mesmo padrão e **mesmo seletor de período**): **Estratégia**, **Vendas e metas** e **Resultado** (descritas abaixo).

## A visão da diretoria

Vem de `planejamento/planejamento-estrategico-2026.xlsx` (OKRs, meta de receita de cada mês, clientes de 2025, orçamento de despesas), de `Vendas ….xlsx` e `Despesas ….xlsx` (em `novos-arquivos/`) e das fotos em `produtos/`. As notas dos fornecedores são a matéria-prima.

- **Última data dos dados** = a última data das vendas (hoje 25/11/2026). O mês em andamento conta **proporcional aos dias** (dia ÷ dias do mês) na meta de receita e no orçamento. Mês sem dados (dezembro) fica vazio.
- **Vendas e metas:** receita contra a meta mês a mês; por produto (com foto), canal e cliente; cliente que não está em "Clientes em 2025" leva o selo "novo em 2026".
- **Resultado:** receita − matéria-prima − despesas = resultado; margem = resultado ÷ receita. **Matéria-prima = o valor faturado das notas dos fornecedores** (o mesmo "Faturado" do painel, por data de emissão), não o "a pagar". Despesas contra o orçamento, por categoria. A despesa de matéria-prima **não** entra no arquivo de despesas.
- **Estratégia:** os 9 resultados-chave, medidos **de 1/1 até o fim do período escolhido** (ou até a última data dos dados), contra o **ritmo esperado** nessa data. Ritmo: meta de receita acumulada (receita do ano, amaciante); meta × fração do ano (cobrado a mais, clientes novos); a própria meta nos percentuais (resultado operacional, notas sem ajuste, distribuidor) e no orçamento (100 %). Estado: **no ritmo** (alcançou o ritmo), **atenção** (até 10 % abaixo, ou até 10 % acima do limite) e **fora do ritmo** (além disso).
  - **Como a página mostra** (só apresentação, nenhuma conta): cartões em 2 colunas; cada um traz o **% do ritmo** em destaque (realizado ÷ ritmo, a mesma razão que decide o estado), o estado colado no nome, os três números em colunas e a barra medida **contra o ritmo** (marca preta = ritmo). Nos "no máximo", o % é do **limite no ritmo** e passar de 100 % é ruim; no "nenhum lote reprovado pago" (limite zero) aparece "Dentro" ou "Passou".
  - *Notas liberadas sem ajuste* = valor das notas liberadas, sem cobrança, ÷ faturado.
  - *Nenhum lote reprovado pago* = valor **liberado para pagar** de lote fora da especificação, sem especificação ou sem laudo (o sistema retém esses lotes).
  - *Clientes novos no atacado* = clientes do canal Atacado que não estão em "Clientes em 2025".

Venda repetida = mesma NF de saída; despesa repetida = mesma data, categoria, descrição e valor. A repetição não entra e é listada.

## Como eu confiro

O **total das notas na tela bate com o total dos arquivos**, por fornecedor, e **cada nota aparece uma vez só**.
- `python3 programa/conferir.py` relê os arquivos de `arquivos-lidos/` por um caminho próprio (só soma a coluna de valor) e compara com o que está no `painel.html`. Sai também em `conferencia.txt`.
- `python3 programa/testar_painel.py` abre o painel no Chrome sem tela e clica em todos os botões (períodos, menu, cartões, tabelas, fornecedores). Precisa do Google Chrome instalado.
- Na visão da diretoria, a conferência soma **o arquivo de vendas contra a receita da tela** e **o arquivo de despesas contra as despesas da tela**, no total e mês a mês.
- **Só diga que terminou se a conferência bater.**

## O que cada pasta faz

| Pasta ou arquivo | O que é | Posso mexer? |
|---|---|---|
| `novos-arquivos/` | onde caem as notas e os laudos dos fornecedores e as **vendas** e **despesas** do período | **Sim: é aqui que eu solto os arquivos.** O programa esvazia ao ler |
| `arquivos-lidos/` | os arquivos já lidos, por data de leitura | Não apague: a conferência lê daqui |
| `cadastros/` | pedidos de compra (com o que o almoxarifado recebeu) e especificação das matérias-primas | **Sim: é meu.** Atualize quando houver pedido novo ou revisão. O programa relê a cada rodada |
| `fornecedores/` | cadastro, logo e foto de cada fornecedor | Sim (um fornecedor novo exige ajuste no programa) |
| `documentos-padrao/` | a carta-modelo ao fornecedor | Sim, mantendo os campos `[entre colchetes]` |
| `planejamento/` | o planejamento estratégico de 2026 (OKRs, metas de receita, clientes de 2025, orçamento) | **Sim: é da diretoria.** O programa relê a cada rodada |
| `produtos/` | a foto de cada produto da Serra Azul (o nome do arquivo tem de estar no nome do produto) | Sim |
| `identidade-visual/` | o design system e o logo da empresa | Só o dono do padrão visual |
| `historico/` | o que já foi lido (notas, laudos, repetidas, log de leituras) | **Não, nunca à mão.** O programa cuida |
| `programa/` | o programa em Python (`atualizar.py`, `leitores.py`, `cruzar.py`, `conferir.py`, ...) | Só o assistente, quando um formato mudar |
| `painel.html`, `conferencia.txt` | o resultado, refeito a cada atualização | Não edite: é gerado |
| `cartas/`, `resumos/` | cartas aos fornecedores (.docx) e resumos para a diretoria | Sim |
| `.claude/skills/` | as tarefas que se repetem (abaixo) | Sim, com cuidado |
| `00-aqui-paramos.md` | onde paramos | Atualizado a cada rodada |

## Skills desta pasta

- **`atualizar-painel`**: "leia os novos arquivos" (fornecedores, vendas e despesas).
- **`carta-ao-fornecedor`**: "escreva a carta à <fornecedor> sobre a nota <número>". Parte de `documentos-padrao/modelo-carta-ao-fornecedor.docx`; salva em `cartas/`.
- **`resumo-do-mes`**: "resumo de <mês> para a diretoria". Salva em `resumos/`.

## Padrão visual

O padrão visual da empresa mora em **`identidade-visual/design-system-serra-azul.md`** (cores, tipografia, esqueleto da tela, componentes, gráficos). Todo painel e relatório em tela segue esse arquivo; o logo da empresa é `identidade-visual/logo-serra-azul.png`. Se o padrão mudar, muda lá, não aqui. O gerador do painel usa o arquivo `programa/painel.template.html`.

## Limites

- O programa **não paga, não escreve ao fornecedor e não apaga arquivo**. Quem decide e quem envia é a coordenação de suprimentos.
- Só as bibliotecas que já existem (Python 3, openpyxl, python-docx, Pillow). **Se faltar uma, peça antes de instalar.**
- Nada de internet no painel e nenhum servidor.
