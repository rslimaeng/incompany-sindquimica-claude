# Design system · Química Serra Azul

O padrão visual dos sistemas internos da Química Serra Azul (empresa fictícia, material de curso). Vale para todo painel, relatório em tela e sistema que a empresa usa. Claro, limpo, com cara de sistema de verdade: o dado é o protagonista.

## 1 · Princípios

- **O número primeiro.** Quem abre a tela quer saber quanto, de quem e o que fazer. O resto é apoio.
- **Uma cor tem um significado.** Verde é liberado, âmbar é atenção, vermelho é retido ou bloqueado. Nunca use cor só para enfeitar.
- **Tudo clicável leva a um detalhe.** Um número grande abre a lista que o compõe; um fornecedor abre a página dele.
- **Funciona sem internet.** A tela abre com dois cliques, direto do arquivo. Nada carrega de fora: gráfico desenhado em SVG, imagem da própria pasta.

## 2 · Cores

| Papel | Cor | Uso |
|---|---|---|
| Fundo da tela | `#F6F7F9` | o fundo de tudo |
| Cartão | `#FFFFFF` | cartões, tabelas, menu lateral |
| Linha fina | `#E5E7EB` | bordas de cartão e divisórias de tabela |
| Texto | `#0F172A` | títulos e números |
| Texto de apoio | `#64748B` | rótulos, legendas, eixos |
| Marca · Serra Azul | `#11355F` | logo, item ativo do menu, cabeçalho de tabela |
| Destaque · liberado | `#10B981` (texto `#059669`) | positivo, liberado, linha principal do gráfico |
| Atenção | `#F59E0B` (texto `#B45309`) | divergência a conferir, preço acima |
| Retido ou bloqueado | `#E11D48` (texto `#BE123C`) | lote fora, nota bloqueada |
| Comparação | `#7C3AED` | segunda série do gráfico, quando houver |

Fundo de selo: a mesma cor com 10 % de opacidade, e o texto na cor escura dela.

## 3 · Tipografia

Fonte **Geist**; sem internet, a fonte do sistema (`system-ui, -apple-system, "Segoe UI", sans-serif`). Números com `font-variant-numeric: tabular-nums`, para as colunas alinharem.

| Elemento | Tamanho e peso |
|---|---|
| Número grande do cartão | 30px, 600 |
| Número de destaque (saldo, total) | 36px, 600 |
| Título da tela | 24px, 600 |
| Título de cartão | 15px, 600 |
| Texto | 14px, 400 |
| Rótulo de cartão | 13px, 500, cor de apoio |
| Rótulo de grupo do menu | 11px, 600, maiúsculas, espaçado |
| Eixo de gráfico e legenda | 11px, 400, cor de apoio |

Dinheiro sempre em real e no formato brasileiro: `R$ 1.234.567,89`. Em cartão, pode abreviar: `R$ 1,25 mi`, `R$ 48 mil`. Data: `19/08/2026`.

## 4 · O esqueleto da tela

```
┌───────────┬──────────────────────────────────────────────────────┐
│  logo     │  Painel / Visão geral         [Jul Ago Set Tri]  🔍 │  ← cabeçalho fixo
│           ├──────────────────────────────────────────────────────┤
│ VISÃO     │  [cartão] [cartão] [cartão] [cartão]                 │  ← 4 números grandes
│  Painel   │  [gráfico de área, 2/3]        [barras por forn., 1/3]│
│ PAGAMENTO │  [tabela de pendências, 2/3]   [últimas notas, 1/3]   │
│  A pagar  │                                                      │
│  Retidos  │                                                      │
│ FORNEC.   │                                                      │
│  ...      │                                                      │
│ usuário   │                                                      │
└───────────┴──────────────────────────────────────────────────────┘
```

- **Menu lateral:** 264px, cartão branco, borda direita fina. Logo no topo. Itens em grupos com rótulo; item com 10px de raio, 10px × 16px de respiro, ícone à esquerda. Item ativo: fundo da marca com 8 % de opacidade e texto da marca. Embaixo, o usuário (nome e cargo).
- **Cabeçalho:** 64px, fixo no topo, fundo branco com 80 % de opacidade e desfoque. À esquerda, a trilha (`Painel / Visão geral`). À direita, o seletor de período (botões colados, o escolhido em branco com sombra leve sobre um trilho cinza), a busca e "Atualizado em 19/11, 10h42".
- **Conteúdo:** grade de 12 colunas, 24px entre os cartões, 32px de margem.
- **Celular:** o menu vira um botão no cabeçalho, e os cartões empilham.

## 5 · Componentes

- **Cartão:** branco, borda fina, raio 16px, 24px de respiro, sombra quase nenhuma (`0 1px 2px rgba(15,23,42,.04)`). Ao passar o mouse, a borda escurece um tom.
- **Cartão de número:** rótulo em cima, número grande, e um selo de variação ("+12,5 % vs. mês anterior", verde ou vermelho). Clicar leva à lista.
- **Selo de situação:** pílula, 12px, 600: `Liberado` verde, `Conferir` âmbar, `Retido` vermelho, `Bloqueado` vermelho com borda.
- **Barra de composição:** uma barra fina (6px), dividida nas partes do total, com a legenda em pontos coloridos embaixo.
- **Tabela:** cabeçalho com texto de apoio em 12px maiúsculo; linhas de 48px com divisória fina; número alinhado à direita; ao passar o mouse, fundo `#F8FAFC`. Ordena ao clicar no cabeçalho. Busca filtra na hora.
- **Lista de atividade:** ícone em quadrado de 32px com raio 8px, título, data em cinza, valor à direita (verde se liberado).
- **Página do fornecedor:** a foto como capa (altura 160px, cantos arredondados), o logo num círculo branco sobre a capa, o contato e o prazo de pagamento, os 4 números só dele e a tabela das notas dele.
- **Ícones:** traço fino, 18px, desenhados em SVG na própria página.

## 6 · Gráficos

- **Área:** linha de 2px na cor de destaque, área com degradê da mesma cor de 20 % a 0 %. A comparação vai tracejada (4 4). Grade horizontal clarinha, sem grade vertical.
- **Barras:** cantos de cima arredondados (4px), 60 % da largura da coluna, empilhadas quando mostram composição (liberado, retido, bloqueado, cobrado a mais).
- **Dica ao passar o mouse:** caixa escura (`#0F172A`, 90 %), texto branco 12px, com a data e o valor.
- **Eixos:** 11px, cor de apoio, valores abreviados (`R$ 2 mi`).
- **Animação:** só na entrada, curta (400 ms). Nada pisca nem gira sozinho.

## 7 · Tom do texto na tela

Português do Brasil, frases curtas, verbo no começo do botão ("Gerar carta", "Ver notas"). Nada de jargão do sistema: o rótulo diz o que a pessoa ganha.
