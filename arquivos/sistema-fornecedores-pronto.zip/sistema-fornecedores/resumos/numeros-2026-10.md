# Números do período 2026-10

- Notas: 30
- Faturado: R$ 1.257.910,00
- Liberado para pagar: R$ 1.240.910,00
- Retido: R$ 17.000,00
- Bloqueado: R$ 0,00
- Cobrado a mais: R$ 0,00

## Por fornecedor

| Fornecedor | Notas | Faturado | Liberado | Retido | Bloqueado | Cobrado a mais |
|---|---|---|---|---|---|---|
| Aromas | 6 | R$ 77.200,00 | R$ 77.200,00 | R$ 0,00 | R$ 0,00 | R$ 0,00 |
| Brisamar | 6 | R$ 191.300,00 | R$ 191.300,00 | R$ 0,00 | R$ 0,00 | R$ 0,00 |
| Carnauba | 6 | R$ 249.750,00 | R$ 249.750,00 | R$ 0,00 | R$ 0,00 | R$ 0,00 |
| Polar | 6 | R$ 100.660,00 | R$ 83.660,00 | R$ 17.000,00 | R$ 0,00 | R$ 0,00 |
| Quimisol | 6 | R$ 639.000,00 | R$ 639.000,00 | R$ 0,00 | R$ 0,00 | R$ 0,00 |

## Notas que pedem decisão

- Polar, nota 3359 (22/10), retido, R$ 17.000,00: lote sem laudo
