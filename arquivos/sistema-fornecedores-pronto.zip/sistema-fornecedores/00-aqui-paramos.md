# Onde paramos

**Atualizado em 26/11/2026, 11h53** · rodada: vendas e despesas de novembro (1 a 25/11)

## Estado

- O painel tem **323 notas** de fornecedor (04/01 a 18/11), **972 notas de saída de vendas** (01/01 a 25/11) e **220 lançamentos de despesa** (06/01 a 25/11). **A última data dos dados é 25/11/2026.** Dezembro está sem dados.
- A conferência **bate**: fornecedores (por fornecedor), **receita da tela = arquivo de vendas** e **despesas da tela = arquivo de despesas**, no total e mês a mês. Cada nota, uma vez só.
- Painel testado no Chrome sem tela (`python3 programa/testar_painel.py`): 126 verificações, 0 falhas.
- A carta à Brisamar sobre a nota 8847 está como **rascunho** em `cartas/carta-brisamar-nf8847.docx`. **Não foi enviada.** O prazo (03/12/2026) é sugestão.

## Arquivos lidos

- `arquivos-lidos/2026-11-26_11h42/`: notas e laudos de janeiro a outubro dos 5 fornecedores.
- `arquivos-lidos/2026-11-26_11h43/`: notas e laudos de novembro dos 5 fornecedores.
- `arquivos-lidos/2026-11-26_11h48/`: `Vendas jan_out.xlsx` e `Despesas jan_out.xlsx`.
- `arquivos-lidos/2026-11-26_11h52/` (**esta rodada**): `Vendas nov.xlsx` (96 notas de saída, R$ 2.699.965,30, de 01 a 25/11) e `Despesas nov.xlsx` (20 lançamentos, R$ 1.047.921,18, de 05 a 25/11).
- `novos-arquivos/` está vazia.

## Números até 25/11 (R$)

| | Ano | Junho | Agosto | Novembro (até 25/11) |
|---|---|---|---|---|
| Receita | 32.114.206,60 | 2.809.296,20 | 3.213.387,90 | 2.699.965,30 |
| Meta do período | 32.148.000,00 | 3.024.000,00 | 3.132.000,00 | 2.700.000,00 |
| Receita ÷ meta | 99,9 % | 92,9 % | 102,6 % | 100,0 % |
| Matéria-prima (notas) | 12.598.083,00 | 1.217.170,00 | 1.191.190,00 | 683.730,00 |
| Despesas | 13.262.366,08 | 1.229.520,39 | 1.325.478,68 | 1.047.921,18 |
| Orçamento | 13.115.816,67 | 1.219.900,00 | 1.237.500,00 | 1.045.916,67 |
| Resultado | 6.253.757,52 | 362.605,81 | 696.719,22 | 968.314,12 |
| Margem | 19,5 % | 12,9 % | 21,7 % | 35,9 % |

🔴 **A margem de novembro (35,9 %) está inflada:** as notas dos fornecedores vão só até 18/11, e as vendas e as despesas, até 25/11. A matéria-prima de novembro está incompleta.

Pagamento de fornecedores (acumulado, janeiro a novembro): faturado R$ 12.598.083,00 · liberado R$ 12.296.097,00 · retido R$ 261.760,00 · bloqueado R$ 16.800,00 · cobrado a mais R$ 23.426,00.

## Os 9 resultados-chave em 25/11

| Resultado-chave | Realizado | Ritmo | Estado |
|---|---|---|---|
| Receita do ano | R$ 32.114.206,60 | R$ 32.148.000,00 | atenção (99,9 % do ritmo) |
| Resultado operacional | 19,5 % | 18 % | no ritmo |
| Despesas dentro do orçamento | 101,1 % | 100 % | atenção |
| Notas liberadas sem ajuste | 93,7 % | 97 % | atenção |
| Nenhum lote reprovado pago | R$ 0,00 | R$ 0,00 | no ritmo |
| Cobrado a mais no ano | R$ 23.426,00 | R$ 18.027,40 (limite de R$ 20.000 no ano, já estourado) | fora do ritmo |
| Receita de amaciante | R$ 4.153.191,50 | R$ 3.572.000,00 (meta do ano R$ 4.000.000, já batida) | no ritmo |
| Canal distribuidor | 25,06 % | 25 % | no ritmo |
| Clientes novos no atacado | 1 (Atacadão Cariri, desde agosto) | 1,8 | fora do ritmo |

## Pendente de decisão

**Diretoria (novo):** Manutenção estourou o orçamento em junho (191 % do orçado) e está acima no ano; o cobrado a mais já passou do limite do ano; falta um cliente novo no atacado.
**Fornecedores (continuam abertos):**
- **Bloqueadas (sem pedido):** Aromas 781 (R$ 5.700,00) e Brisamar 8847 (R$ 11.100,00).
- **Retidas pela qualidade:** Aromas 787, Brisamar 8851, Carnaúba 1571, Polar 3316, Polar 3359, Quimisol 41240; de novembro, **Aromas 824** (Essência de eucalipto sem especificação cadastrada) e **Brisamar 8862** (ferro 13,0 acima de 10).
- **A cobrar:** Aromas 813, Brisamar 8828 e 8855, Polar 3332 e 3345, Quimisol 41207, 41213, 41247 e **41262**. Total R$ 23.426,00.
- **Repetidas, que não entraram:** Carnaúba 1578 e Polar 3325.

## Para a próxima vez

1. Solte em `novos-arquivos/` as notas e os laudos dos fornecedores e as vendas e as despesas do período novo.
2. Abra uma conversa nesta pasta e diga só: **leia os novos arquivos**.
3. Ao fim, esta página é reescrita (regra do `CLAUDE.md`).

## Decisões do assistente que o usuário ainda não confirmou

- O período de uma nota é a **data de emissão**. O veredito de qualidade é do nosso cruzamento com a especificação, não o "Aprovado" do fornecedor.
- **Matéria-prima no Resultado** = valor faturado das notas dos fornecedores (não o "a pagar").
- **Meta e orçamento do mês em andamento** contam proporcional aos dias até 25/11. O estado dos resultados-chave: atenção até 10 % do ritmo; fora além disso.
- Matéria-prima sem especificação cadastrada fica **retida**.
