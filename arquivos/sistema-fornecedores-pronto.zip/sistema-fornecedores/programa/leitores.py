"""Leitores: transformam cada arquivo que chega (xlsx ou csv, cada fornecedor num formato)
em registros padronizados. Lê por CABEÇALHO, não por posição de coluna."""
import csv, re, unicodedata, datetime as dt
from pathlib import Path
import openpyxl

FORNECEDORES = ["Aromas", "Brisamar", "Carnauba", "Polar", "Quimisol"]
ANO_PADRAO = 2026
MESES = {"jan": 1, "fev": 2, "mar": 3, "abr": 4, "mai": 5, "jun": 6, "jul": 7, "ago": 8, "set": 9, "out": 10, "nov": 11, "dez": 12}


def sem_acento(s):
    return "".join(c for c in unicodedata.normalize("NFD", str(s)) if unicodedata.category(c) != "Mn")


def norm(s):
    """minúsculo, sem acento, sem pontuação sobrando: para comparar nomes."""
    return re.sub(r"\s+", " ", sem_acento(s).lower().replace("·", " ")).strip()


def num(x):
    """Número em qualquer formato: 9.82 | '9,82' | 'R$ 14.800,00' | '25.500,00' | '8,0 t' -> float. None se não for número."""
    if x is None or x == "":
        return None
    if isinstance(x, bool):
        return None
    if isinstance(x, (int, float)):
        return float(x)
    s = str(x).strip()
    s = re.sub(r"[^\d,.\-]", "", s.replace("R$", ""))
    if not re.search(r"\d", s):
        return None
    if "," in s:
        s = s.replace(".", "").replace(",", ".")
    elif s.count(".") > 1 or re.fullmatch(r"-?\d{1,3}(\.\d{3})+", s):
        s = s.replace(".", "")
    try:
        return float(s)
    except ValueError:
        return None


def quantidade_kg(x, cabecalho=""):
    """'8,0 t' -> 8000 ; '150 kg' -> 150 ; número puro -> kg (avisa se a unidade não está clara)."""
    aviso = None
    if isinstance(x, (int, float)):
        h = norm(cabecalho)
        if re.search(r"\bt\b|ton", h):
            return float(x) * 1000, None
        if "kg" not in h:
            aviso = "quantidade sem unidade, assumi kg"
        return float(x), aviso
    s = str(x).strip().lower()
    n = num(s)
    if n is None:
        return None, "quantidade ilegível: %r" % x
    if re.search(r"\d\s*(t|ton|toneladas?)\b", s):
        return n * 1000, None
    if re.search(r"\d\s*kg\b", s):
        return n, None
    if re.search(r"kg", norm(cabecalho)):
        return n, None
    return n, "quantidade sem unidade, assumi kg"


def data(x, ano=ANO_PADRAO):
    if isinstance(x, dt.datetime):
        return x.date()
    if isinstance(x, dt.date):
        return x
    if x is None:
        return None
    s = str(x).strip().lower()
    m = re.fullmatch(r"(\d{4})-(\d{2})-(\d{2})", s)
    if m:
        return dt.date(int(m[1]), int(m[2]), int(m[3]))
    m = re.fullmatch(r"(\d{1,2})/(\d{1,2})/(\d{2,4})", s)
    if m:
        a = int(m[3]); a = a + 2000 if a < 100 else a
        return dt.date(a, int(m[2]), int(m[1]))
    m = re.fullmatch(r"(\d{1,2})/([a-zç]{3})[a-z]*/(\d{2,4})", sem_acento(s))
    if m and m[2] in MESES:
        a = int(m[3]); a = a + 2000 if a < 100 else a
        return dt.date(a, MESES[m[2]], int(m[1]))
    m = re.fullmatch(r"(\d{1,2})/(\d{1,2})", s)
    if m:
        return dt.date(ano, int(m[2]), int(m[1]))
    return None


def lote_norm(x):
    if x is None:
        return None
    s = str(x).strip()
    if re.fullmatch(r"\d+(\.0)?", s):
        s = str(int(float(s))).zfill(7)
    return s


def pedido_norm(x):
    """'PC 2026-0003' | 'PC-2026-0003' | '0001' | 'ref. pedido PC-2026-0002' -> 'PC-2026-0003'. None se não houver pedido."""
    if x is None:
        return None
    s = str(x)
    m = re.search(r"PC[\s\-]*(\d{4})[\s\-]*(\d{4})", s, re.I)
    if m:
        return "PC-%s-%s" % (m[1], m[2])
    m = re.fullmatch(r"\s*(\d{1,4})\s*", s)
    if m:
        return "PC-%d-%04d" % (ANO_PADRAO, int(m[1]))
    return None


def nota_norm(x):
    if x is None:
        return None
    s = str(x).strip()
    s = re.sub(r"^(nf-?e?|nota)\s*", "", s, flags=re.I)
    s = re.sub(r"\.0$", "", s)
    return s if re.fullmatch(r"\d+", s) else None


def identificar(nome_arquivo):
    """'Aromas notas nov.xlsx' -> ('Aromas', 'notas'). None se não for de um fornecedor conhecido."""
    n = norm(nome_arquivo)
    forn = next((f for f in FORNECEDORES if n.startswith(norm(f))), None)
    tipo = "notas" if re.search(r"\bnotas?\b", n) else "laudos" if re.search(r"\blaudos?\b", n) else None
    return forn, tipo


def _linhas(caminho):
    """[(nome_da_aba, [linhas...])] de xlsx ou csv. Aba 'observações' e semelhantes não entram."""
    p = Path(caminho)
    if p.suffix.lower() == ".csv":
        raw = p.read_bytes()
        txt = None
        for enc in ("utf-8-sig", "cp1252", "latin-1"):
            try:
                txt = raw.decode(enc); break
            except UnicodeDecodeError:
                continue
        amostra = txt[:2000]
        sep = ";" if amostra.count(";") >= amostra.count(",") else ","
        rows = [r for r in csv.reader(txt.splitlines(), delimiter=sep)]
        return [("csv", rows)]
    wb = openpyxl.load_workbook(p, data_only=True)
    out = []
    for ws in wb.worksheets:
        if re.search(r"observa|uso interno|leia", norm(ws.title)):
            continue
        out.append((ws.title, [list(r) for r in ws.iter_rows(values_only=True)]))
    return out


SINON_NOTAS = [
    ("nota", r"^(nota|n[o°º]? ?nf|nf-?e?|numero)\b|^n[°º]? ?nf"),
    ("data", r"^(data|emissao)"),
    ("pedido", r"pedido"),
    ("produto", r"^(produto|item|material|descricao)"),
    ("lote", r"^lote"),
    ("qtd", r"^(quantidade|qtde|qtd|kg$)"),
    ("preco", r"(preco|vlr unit|valor unit)"),
    ("valor", r"^(valor|total|vlr total|valor total)"),
    ("obs", r"^(observ|obs)"),
]


def _mapear_cabecalho(linha, sinonimos):
    mapa = {}
    for i, c in enumerate(linha):
        if c is None:
            continue
        h = norm(c)
        for campo, rx in sinonimos:
            if campo not in mapa and re.search(rx, h):
                mapa[campo] = i
                break
    return mapa


def _acha_cabecalho(linhas, obrigatorios, sinonimos, limite=12):
    for i, l in enumerate(linhas[:limite]):
        m = _mapear_cabecalho(l, sinonimos)
        if all(k in m for k in obrigatorios):
            return i, m
    return None, None


def _ano_do_titulo(linhas):
    for l in linhas[:3]:
        for c in l:
            m = re.search(r"\b(20\d\d)\b", str(c or ""))
            if m:
                return int(m[1])
    return ANO_PADRAO


def ler_notas(caminho, fornecedor):
    """-> dict(registros=[...], avisos=[...], totais_declarados=[valor...], linhas_lidas=N)"""
    regs, avisos, declarados = [], [], []
    for aba, linhas in _linhas(caminho):
        i, m = _acha_cabecalho(linhas, ["nota", "lote", "valor"], SINON_NOTAS)
        if i is None:
            if any(any(c not in (None, "") for c in l) for l in linhas):
                avisos.append("aba %r: não achei cabeçalho de notas (nota, lote, valor)" % aba)
            continue
        ano = _ano_do_titulo(linhas[:i + 1])
        cab = linhas[i]
        for l in linhas[i + 1:]:
            l = list(l) + [None] * (len(cab) - len(l))
            texto = " ".join(str(c) for c in l if c not in (None, ""))
            if not texto:
                continue
            numero = nota_norm(l[m["nota"]])
            if numero is None:
                mt = re.search(r"total.*?R?\$?\s*([\d.]+,\d{2})", texto, re.I)
                if mt:
                    declarados.append({"aba": aba, "valor": num(mt[1]), "texto": texto})
                else:
                    avisos.append("aba %r: linha ignorada (sem número de nota): %s" % (aba, texto[:70]))
                continue
            valor = num(l[m["valor"]])
            qtd, av = quantidade_kg(l[m["qtd"]], cab[m["qtd"]]) if "qtd" in m else (None, "sem coluna de quantidade")
            if av:
                avisos.append("nota %s: %s" % (numero, av))
            preco = num(l[m["preco"]]) if "preco" in m else None
            ped_txt = " ".join(str(l[m[k]]) for k in ("pedido", "obs") if k in m and l[m[k]] is not None)
            regs.append({
                "fornecedor": fornecedor,
                "nota": numero,
                "data": (data(l[m["data"]], ano) or None) and data(l[m["data"]], ano).isoformat(),
                "pedido_citado": pedido_norm(ped_txt),
                "produto": str(l[m["produto"]]).strip() if "produto" in m else None,
                "lote": lote_norm(l[m["lote"]]),
                "qtd_kg": qtd,
                "preco_nota": preco,
                "valor": valor,
                "obs": str(l[m["obs"]]).strip() if "obs" in m and l[m["obs"]] else None,
                "texto_pedido": ped_txt.strip() or None,
                "arquivo": Path(caminho).name,
                "aba": aba,
            })
    return {"registros": regs, "avisos": avisos, "totais_declarados": declarados, "linhas_lidas": len(regs)}


# ---------------------------------------------------------------- laudos
SINON_LAUDO_LONGO = [
    ("lote", r"^lote"),
    ("produto", r"^(produto|material|descricao)"),
    ("data", r"^(data|emissao|fabricacao)"),
    ("param", r"^(analise|ensaio|parametro)"),
    ("valor", r"^(valor|resultado)"),
    ("unidade", r"^(unidade|un\.?$)"),
    ("situacao", r"^(situacao|conclusao|status)"),
]


def _param(registro, lote, produto, dta, nome, bruto, unidade, concl, arquivo):
    txt = None if bruto is None else str(bruto).strip()
    op = None
    n = num(bruto)
    if txt and txt[0] in "<>":
        op = txt[0]
    return {"lote": lote, "produto": produto, "data": dta.isoformat() if dta else None, "parametro": str(nome).strip(),
            "bruto": txt, "valor": n, "op": op, "unidade": (str(unidade).strip() if unidade else None),
            "conclusao_fornecedor": concl, "arquivo": arquivo}


def ler_laudos(caminho, fornecedor):
    regs, avisos = [], []
    arq = Path(caminho).name
    for aba, linhas in _linhas(caminho):
        ano = _ano_do_titulo(linhas)
        blocos = [i for i, l in enumerate(linhas) if l and l[0] and norm(l[0]).startswith("certificado de analise")]
        if blocos:  # um certificado por bloco
            blocos.append(len(linhas))
            for a, b in zip(blocos, blocos[1:]):
                prod = str(linhas[a][0]).split("·", 1)[-1].strip()
                lote = dta = concl = None
                par = []
                for l in linhas[a + 1:b]:
                    l = list(l) + [None] * 3
                    k = norm(l[0] or "")
                    if k.startswith("lote"): lote = lote_norm(l[1])
                    elif k.startswith("fabricacao") or k.startswith("data"): dta = data(l[1], ano)
                    elif k.startswith("conclusao"): concl = l[1]
                    elif l[0] and l[1] is not None: par.append((l[0], l[1], l[2]))
                for nome, v, u in par:
                    regs.append(_param(None, lote, prod, dta, nome, v, u, concl, arq))
            continue
        i, m = _acha_cabecalho(linhas, ["lote", "param", "valor"], SINON_LAUDO_LONGO)
        if i is not None:  # formato longo: uma linha por análise
            for l in linhas[i + 1:]:
                l = list(l) + [None] * (len(linhas[i]) - len(l))
                if not l[m["lote"]] or not l[m["param"]]:
                    if any(c not in (None, "") for c in l) and l[0]:
                        pass  # linha de rodapé ("Total de lotes no mês: 6")
                    continue
                regs.append(_param(None, lote_norm(l[m["lote"]]), l[m["produto"]] if "produto" in m else None,
                                   data(l[m["data"]], ano) if "data" in m else None, l[m["param"]], l[m["valor"]],
                                   l[m["unidade"]] if "unidade" in m else None,
                                   l[m["situacao"]] if "situacao" in m else None, arq))
            continue
        # formato largo: uma linha por lote, uma coluna por parâmetro ("MP-03 · Teor de NaOH (%)")
        i2, m2 = _acha_cabecalho(linhas, ["lote"], SINON_LAUDO_LONGO)
        if i2 is not None:
            cab = linhas[i2]
            fixas = set(m2.values())
            for l in linhas[i2 + 1:]:
                l = list(l) + [None] * (len(cab) - len(l))
                if not l[m2["lote"]]:
                    continue
                for j, nome in enumerate(cab):
                    if j in fixas or nome is None or l[j] in (None, ""):
                        continue
                    nm = str(nome).split("·", 1)[-1].strip()
                    mu = re.search(r"\(([^()]*)\)\s*$", nm)
                    unidade = mu[1] if mu else None
                    nm = nm[:mu.start()].strip() if mu else nm
                    regs.append(_param(None, lote_norm(l[m2["lote"]]), l[m2["produto"]] if "produto" in m2 else None,
                                       data(l[m2["data"]], ano) if "data" in m2 else None, nm, l[j], unidade, None, arq))
            continue
        if any(any(c not in (None, "") for c in l) for l in linhas):
            avisos.append("aba %r: formato de laudo desconhecido" % aba)
    return {"registros": regs, "avisos": avisos, "linhas_lidas": len(regs)}


def ler(caminho):
    td = tipo_diretoria(Path(caminho).name)
    if td:
        r = ler_vendas(caminho) if td == "vendas" else ler_despesas(caminho)
        r.update(fornecedor=None, tipo=td, arquivo=Path(caminho).name)
        return r
    forn, tipo = identificar(Path(caminho).name)
    if not forn or not tipo:
        return {"erro": "não reconheci o fornecedor/tipo pelo nome do arquivo", "fornecedor": forn, "tipo": tipo}
    r = ler_notas(caminho, forn) if tipo == "notas" else ler_laudos(caminho, forn)
    r.update(fornecedor=forn, tipo=tipo, arquivo=Path(caminho).name)
    return r


# ---------------------------------------------------------------- vendas e despesas (visão da diretoria)
SINON_VENDAS = [
    ("data", r"^data"), ("nf", r"^(nf|nota)"), ("cliente", r"^cliente"), ("canal", r"^canal"),
    ("codigo", r"^cod"), ("produto", r"^(produto|descricao)"), ("qtd", r"^(quantidade|qtde|qtd)"),
    ("preco", r"^(preco|valor unit|vlr unit)"), ("valor", r"^(valor|total|vlr)"),
]
SINON_DESPESAS = [
    ("data", r"^data"), ("centro", r"^centro"), ("categoria", r"^categoria"), ("descricao", r"^descricao"), ("valor", r"^(valor|total|vlr)"),
]


def tipo_diretoria(nome):
    n = norm(nome)
    if re.match(r"^vendas?\b", n):
        return "vendas"
    if re.match(r"^despesas?\b", n):
        return "despesas"
    return None


def ler_vendas(caminho):
    regs, avisos = [], []
    for aba, linhas in _linhas(caminho):
        i, m = _acha_cabecalho(linhas, ["data", "cliente", "valor"], SINON_VENDAS)
        if i is None:
            if any(any(c not in (None, "") for c in l) for l in linhas):
                avisos.append("aba %r: não achei o cabeçalho de vendas (data, cliente, valor)" % aba)
            continue
        ano = _ano_do_titulo(linhas[:i + 1])
        for l in linhas[i + 1:]:
            l = list(l) + [None] * (len(linhas[i]) - len(l))
            if not any(c not in (None, "") for c in l):
                continue
            d, v = data(l[m["data"]], ano), num(l[m["valor"]])
            if d is None or v is None:
                avisos.append("linha ignorada: %s" % " ".join(str(c) for c in l if c)[:70]); continue
            regs.append({"data": d.isoformat(), "nf": str(l[m["nf"]]).strip().replace(".0", "") if "nf" in m else None,
                         "cliente": str(l[m["cliente"]]).strip(), "canal": str(l[m["canal"]]).strip() if "canal" in m else None,
                         "codigo": str(l[m["codigo"]]).strip() if "codigo" in m else None,
                         "produto": str(l[m["produto"]]).strip() if "produto" in m else None,
                         "qtd": num(l[m["qtd"]]) if "qtd" in m else None, "preco": num(l[m["preco"]]) if "preco" in m else None,
                         "valor": v, "arquivo": Path(caminho).name})
    return {"registros": regs, "avisos": avisos, "linhas_lidas": len(regs)}


def ler_despesas(caminho):
    regs, avisos = [], []
    for aba, linhas in _linhas(caminho):
        i, m = _acha_cabecalho(linhas, ["data", "categoria", "valor"], SINON_DESPESAS)
        if i is None:
            if any(any(c not in (None, "") for c in l) for l in linhas):
                avisos.append("aba %r: não achei o cabeçalho de despesas (data, categoria, valor)" % aba)
            continue
        ano = _ano_do_titulo(linhas[:i + 1])
        for l in linhas[i + 1:]:
            l = list(l) + [None] * (len(linhas[i]) - len(l))
            if not any(c not in (None, "") for c in l):
                continue
            d, v = data(l[m["data"]], ano), num(l[m["valor"]])
            if d is None or v is None:
                avisos.append("linha ignorada: %s" % " ".join(str(c) for c in l if c)[:70]); continue
            regs.append({"data": d.isoformat(), "centro": str(l[m["centro"]]).strip() if "centro" in m else None,
                         "categoria": str(l[m["categoria"]]).strip(), "descricao": str(l[m["descricao"]]).strip() if "descricao" in m and l[m["descricao"]] else "",
                         "valor": v, "arquivo": Path(caminho).name})
    return {"registros": regs, "avisos": avisos, "linhas_lidas": len(regs)}
