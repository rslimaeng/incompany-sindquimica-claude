#!/usr/bin/env python3
"""Lê o que chegou em novos-arquivos/, cruza nota x pedido x laudo, guarda o histórico,
move o arquivo lido para arquivos-lidos/, refaz o painel.html e roda a conferência.
Uso:  python3 programa/atualizar.py"""
import datetime as dt, json, shutil, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
import leitores as L, cruzar as C, gerar_painel as G, conferir as K, planejamento as PL

RAIZ = Path(__file__).resolve().parent.parent
NOVOS, LIDOS, HIST = RAIZ / "novos-arquivos", RAIZ / "arquivos-lidos", RAIZ / "historico"


def carregar(nome, padrao):
    p = HIST / nome
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else padrao


def salvar(nome, obj):
    HIST.mkdir(exist_ok=True)
    (HIST / nome).write_text(json.dumps(obj, ensure_ascii=False, indent=1), encoding="utf-8")


def brl(c):
    return "R$ " + f"{c / 100:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def main():
    agora = dt.datetime.now()
    notas = carregar("notas.json", [])
    repetidas = carregar("repetidas.json", [])
    laudos = carregar("laudos.json", {})
    leituras = carregar("leituras.json", [])
    vendas = carregar("vendas.json", [])
    despesas = carregar("despesas.json", [])
    rep_dir = carregar("repetidas-diretoria.json", [])
    chave_v = {v["nf"] or (v["data"], v["cliente"], v["valor"]) for v in vendas}
    chave_d = {(d["data"], d["categoria"], d["descricao"], d["valor"]) for d in despesas}
    chaves = {(n["fornecedor"], n["nota"]): n for n in notas}
    arquivos = sorted(p for p in NOVOS.iterdir() if p.is_file() and not p.name.startswith((".", "~$")))
    if not arquivos:
        print("Nada novo em novos-arquivos/. Refiz o painel com o histórico que já existe.")
    relatorio, ok_para_mover, novas = [], [], []
    for p in arquivos:
        try:
            r = L.ler(p)
        except Exception as e:  # arquivo ilegível não derruba os outros
            r = {"erro": "não consegui abrir: %s" % e}
        if "erro" in r or (not r["registros"]):
            relatorio.append("NÃO LI  %s: %s" % (p.name, r.get("erro") or "; ".join(r["avisos"]) or "nenhum registro"))
            continue
        if r["tipo"] == "vendas":
            soma = 0
            for v in r["registros"]:
                k = v["nf"] or (v["data"], v["cliente"], v["valor"])
                soma += C.cents(v["valor"])
                if k in chave_v:
                    rep_dir.append({"tipo": "vendas", "chave": str(k), "valor": v["valor"], "arquivo": v["arquivo"]})
                    relatorio.append("repetida  venda NF %s (%s) não entra de novo" % (k, brl(C.cents(v["valor"]))))
                else:
                    chave_v.add(k); vendas.append(v)
            relatorio.append("li      %s: %d notas de saída, soma %s, de %s a %s" % (p.name, r["linhas_lidas"], brl(soma), min(x["data"] for x in r["registros"]), max(x["data"] for x in r["registros"])))
        elif r["tipo"] == "despesas":
            soma = 0
            for d in r["registros"]:
                k = (d["data"], d["categoria"], d["descricao"], d["valor"])
                soma += C.cents(d["valor"])
                if k in chave_d:
                    rep_dir.append({"tipo": "despesas", "chave": " ".join(map(str, k)), "valor": d["valor"], "arquivo": d["arquivo"]})
                    relatorio.append("repetida  despesa %s %s (%s) não entra de novo" % (d["data"], d["categoria"], brl(C.cents(d["valor"]))))
                else:
                    chave_d.add(k); despesas.append(d)
            relatorio.append("li      %s: %d lançamentos, soma %s, de %s a %s" % (p.name, r["linhas_lidas"], brl(soma), min(x["data"] for x in r["registros"]), max(x["data"] for x in r["registros"])))
        elif r["tipo"] == "notas":
            soma = 0
            for n in r["registros"]:
                soma += C.cents(n["valor"])
                k = (n["fornecedor"], n["nota"])
                if k in chaves:
                    ig = chaves[k]["valor"] == n["valor"]
                    repetidas.append({"fornecedor": n["fornecedor"], "nota": n["nota"], "data": n["data"], "valor": n["valor"],
                                      "arquivo": n["arquivo"], "mesmo_valor": ig})
                    relatorio.append("repetida  %s nota %s (%s) não entra de novo%s" % (n["fornecedor"], n["nota"], brl(C.cents(n["valor"])), "" if ig else "  ATENÇÃO: valor diferente da primeira vez"))
                else:
                    chaves[k] = n; notas.append(n); novas.append(n)
            relatorio.append("li      %s: %d linhas de nota, soma das linhas %s" % (p.name, r["linhas_lidas"], brl(soma)))
            for t in r["totais_declarados"]:
                relatorio.append("        (o arquivo declara: %s)" % t["texto"][:60])
        else:
            por_lote = {}
            for q in r["registros"]:
                por_lote.setdefault(q["lote"], []).append(q)
            for lote, ps in por_lote.items():
                laudos[lote] = ps
            relatorio.append("li      %s: %d lotes, %d análises" % (p.name, len(por_lote), r["linhas_lidas"]))
        for a in r["avisos"][:5]:
            relatorio.append("        aviso: " + a)
        leituras.append({"quando": agora.isoformat(timespec="seconds"), "arquivo": p.name, "fornecedor": r["fornecedor"], "tipo": r["tipo"], "linhas": r["linhas_lidas"]})
        ok_para_mover.append(p)

    pedidos, specs, forn = C.ler_pedidos(RAIZ), C.ler_specs(RAIZ), C.ler_fornecedores(RAIZ)
    antes = len(notas) - len(novas)
    res = C.cruzar(notas, laudos, pedidos, specs)

    # guarda o histórico e só então move os arquivos lidos
    salvar("notas.json", notas); salvar("repetidas.json", repetidas); salvar("laudos.json", laudos); salvar("leituras.json", leituras)
    salvar("vendas.json", vendas); salvar("despesas.json", despesas); salvar("repetidas-diretoria.json", rep_dir)
    if ok_para_mover:
        destino = LIDOS / agora.strftime("%Y-%m-%d_%Hh%M")
        destino.mkdir(parents=True, exist_ok=True)
        for p in ok_para_mover:
            shutil.move(str(p), str(destino / p.name))
        relatorio.append("movi %d arquivo(s) para arquivos-lidos/%s/" % (len(ok_para_mover), destino.name))

    plan = PL.ler_planejamento(RAIZ)
    dir_ = {"vendas": vendas, "despesas": despesas, "rep": rep_dir, "plan": plan}
    G.gerar(RAIZ, res, repetidas, forn, agora, conferencia=None, diretoria=dir_)
    conf = K.verificar(RAIZ)
    G.gerar(RAIZ, res, repetidas, forn, agora, conferencia=conf, diretoria=dir_)
    K.escrever_relatorio(RAIZ, conf)

    print("\n".join(relatorio))
    print("\nNotas no histórico: %d (eram %d, entraram %d)." % (len(notas), antes, len(novas)))
    if novas:
        ids = {(n["fornecedor"], n["nota"]) for n in novas}
        print("\nO que há de novo para decidir:")
        for r in res:
            if (r["fornecedor"], r["nota"]) in ids and (r["status"] != "liberado" or r["cobrado_c"]):
                print("  %-9s nota %-6s %-10s %s  %s" % (r["fornecedor"], r["nota"], r["status"], brl(r["valor_c"]), " | ".join(r["motivos"])))
    tot = {k: sum(r[k] for r in res) for k in ("valor_c", "liberado_c", "retido_c", "bloqueado_c", "cobrado_c")}
    print("\nAcumulado 2026: faturado %s · liberado %s · retido %s · bloqueado %s · cobrado a mais %s" % tuple(brl(tot[k]) for k in ("valor_c", "liberado_c", "retido_c", "bloqueado_c", "cobrado_c")))
    if vendas:
        print("Vendas no histórico: %d notas de saída, receita %s, até %s. Despesas: %d lançamentos, %s, até %s." % (
            len(vendas), brl(sum(C.cents(v["valor"]) for v in vendas)), max(v["data"] for v in vendas), len(despesas),
            brl(sum(C.cents(d["valor"]) for d in despesas)), max(d["data"] for d in despesas) if despesas else "-"))
    print("\n" + K.texto_conferencia(conf))
    return 0 if conf["tudo_bate"] else 2


if __name__ == "__main__":
    sys.exit(main())
