#!/usr/bin/env python3
"""Abre o painel.html no Chrome sem tela, clica em TODOS os botões por script e confere o resultado.
Uso:  python3 programa/testar_painel.py   (precisa do Google Chrome instalado)"""
import base64, json, re, subprocess, sys, tempfile
from pathlib import Path

CHROME = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
RAIZ = Path(__file__).resolve().parent.parent

SCRIPT = r"""
<script>
window.addEventListener("load",function(){
 const R=[],erros=[];window.addEventListener("error",e=>erros.push(String(e.message)));
 function fim(){const pre=document.createElement("pre");pre.id="__resultado";pre.textContent=btoa(unescape(encodeURIComponent(JSON.stringify(R))));document.body.appendChild(pre)}
 try{
 const $=s=>document.querySelector(s),$$=s=>Array.from(document.querySelectorAll(s));
 const cartoes=()=>{const o={};$$("#conteudo .num[data-card]").forEach(c=>o[c.dataset.card]=+c.dataset.valor);return o};
 const reg=(passo,ok,det)=>R.push({passo,ok:!!ok,det:det===undefined?null:det});
 const clique=el=>{if(!el)return false;el.click();return true};
 // 1. período: cada modo e cada botão de período
 const periodos=[];
 clique($('#seg button[data-modo="ano"]'));
 periodos.push({modo:"ano",per:2026,v:cartoes()});
 clique($('#seg button[data-modo="mes"]'));
 for(let m=1;m<=12;m++){const b=$('#sub .chip[data-modo="mes"][data-per="'+m+'"]');const ok=clique(b);periodos.push({modo:"mes",per:m,achou:ok,v:cartoes(),h1:$("#conteudo h1").textContent})}
 clique($('#seg button[data-modo="tri"]'));
 for(let q=1;q<=4;q++){const b=$('#sub .chip[data-modo="tri"][data-per="'+q+'"]');const ok=clique(b);periodos.push({modo:"tri",per:q,achou:ok,v:cartoes(),h1:$("#conteudo h1").textContent})}
 clique($('#seg button[data-modo="ano"]'));
 periodos.push({modo:"ano",per:2026,achou:!!$('#sub .chip[data-modo="ano"]'),v:cartoes(),h1:$("#conteudo h1").textContent});
 R.push({passo:"periodos",dados:periodos});
 // 2. menu: cada item
 clique($('#seg button[data-modo="mes"]'));clique($('#sub .chip[data-per="10"]'));
 const nav=[];
 $$("#side .nav").forEach((_,i)=>{const b=$$("#side .nav")[i];const rot=b.textContent.trim();b.click();nav.push({rot,pagina:document.body.dataset.pagina,h1:($("#conteudo h1")||{}).textContent,tabelaLinhas:$$("#conteudo tbody tr").length})});
 R.push({passo:"menu",dados:nav});
 // 3. cartões do painel levam à lista
 clique($('#side .nav[data-pag="painel"]'));
 const levam=[];
 ["v","li","re","bl","co"].forEach(k=>{clique($('#side .nav[data-pag="painel"]'));const c=$('#conteudo .num[data-card="'+k+'"]');const alvo=c.dataset.pag;c.click();levam.push({card:k,pagina:document.body.dataset.pagina})});
 R.push({passo:"cartoes_levam_a_lista",dados:levam});
 // 4. busca e ordenação em tabela
 clique($('#side .nav[data-pag="notas"]'));clique($('#seg button[data-modo="ano"]'));
 const antes=$$("#conteudo tbody tr").length;
 const inp=$('#conteudo input[data-busca]');inp.value="8851";inp.dispatchEvent(new Event("input",{bubbles:true}));
 const depois=$$("#conteudo tbody tr").length,tx=($("#conteudo tbody tr")||{}).textContent||"";
 inp.value="";inp.dispatchEvent(new Event("input",{bubbles:true}));
 const volta=$$("#conteudo tbody tr").length;
 $$("#conteudo th")[4].click();const v1=$("#conteudo tbody tr td:nth-child(5)").textContent;$$("#conteudo th")[4].click();const v2=$("#conteudo tbody tr td:nth-child(5)").textContent;
 R.push({passo:"busca_e_ordem",dados:{antes,depois,volta,primeiraLinhaTemNota8851:/8851/.test(tx),menorOuMaior:[v1,v2]}});
 // 5. gaveta da nota
 $("#conteudo tbody tr").click();const aberta=$("#gaveta").classList.contains("on");const titulo=$("#gaveta h2").textContent;
 const cop=$('#gaveta [data-act="copiar"]');cop.click();const msgEl=$("#msg-copia");
 $('#gaveta [data-act="fechar"]').click();const fechada=!$("#gaveta").classList.contains("on");
 const gav={aberta,titulo,fechada};R.push({passo:"gaveta",dados:gav});
 // 6. cada fornecedor
 const forn=[];
 $$("#side .nav[data-forn]").forEach((_,i)=>{const b=$$("#side .nav[data-forn]")[i];b.click();
   const imgs=$$("#conteudo img").map(x=>({src:x.src.slice(0,22),alt:x.alt}));
   forn.push({botao:b.textContent.trim(),pagina:document.body.dataset.pagina,h1:$("#conteudo h1").textContent,imgs,cartoes:cartoes(),linhas:$$("#conteudo tbody tr").length})});
 R.push({passo:"fornecedores",dados:forn});
 // 7. análise: clicar na linha de cada fornecedor abre a página dele
 const lin=[];
 for(let i=0;i<5;i++){clique($('#side .nav[data-pag="analise"]'));const tr=$$('#conteudo tr[data-act="forn"]')[i];const f=tr.dataset.forn;tr.click();lin.push({esperado:"f:"+f,pagina:document.body.dataset.pagina})}
 R.push({passo:"analise_linha_abre_fornecedor",dados:lin});
 // 8. filtros do "o que fazer"
 clique($('#side .nav[data-pag="fazer"]'));clique($('#seg button[data-modo="ano"]'));
 const fl=[];$$("#conteudo .chip[data-act=filtro]").forEach((_,i)=>{$$("#conteudo .chip[data-act=filtro]")[i].click();fl.push({chip:$("#conteudo .chip.on").textContent,linhas:$$("#conteudo tbody tr").length})});
 R.push({passo:"filtros_fazer",dados:fl});
 // 9. conferência
 clique($('#side .nav[data-pag="conferencia"]'));
 R.push({passo:"conferencia",dados:{pills:$$("#conteudo .pill").map(p=>p.textContent),total:$("#conf-total")?+$("#conf-total").dataset.valor:null}});
 // 10. busca global
 const bg=$("#busca-global");bg.value="1571";bg.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter",bubbles:true}));
 R.push({passo:"busca_global",dados:{pagina:document.body.dataset.pagina,linhas:$$("#conteudo tbody tr").length}});
 // 11. botão do menu (celular) e "ver todas as pendências"
 clique($('#side .nav[data-pag="painel"]'));clique($('#seg button[data-modo="mes"]'));
 clique($('#conteudo [data-act="nav"][data-pag="fazer"]:not(.num)'));R.push({passo:"ver_todas_pendencias",dados:document.body.dataset.pagina});
 $('.menu-btn').click();R.push({passo:"botao_menu",dados:$("#side").classList.contains("on")});

 // 11b. visão da diretoria: períodos em cada página nova
 const dir={};
 const rodarPeriodos=(pag,coletor)=>{clique($('#side .nav[data-pag="'+pag+'"]'));const out=[];
   clique($('#seg button[data-modo="ano"]'));out.push({modo:"ano",per:2026,v:coletor()});
   clique($('#seg button[data-modo="mes"]'));for(let m=1;m<=12;m++){clique($('#sub .chip[data-modo="mes"][data-per="'+m+'"]'));out.push({modo:"mes",per:m,v:coletor()})}
   clique($('#seg button[data-modo="tri"]'));for(let q=1;q<=4;q++){clique($('#sub .chip[data-modo="tri"][data-per="'+q+'"]'));out.push({modo:"tri",per:q,v:coletor()})}
   return out};
 const cartDir=()=>{const o={};$$("#conteudo .num[data-card]").forEach(c=>o[c.dataset.card]=+c.dataset.valor);return o};
 dir.vendas=rodarPeriodos("vendas",cartDir);
 dir.resultado=rodarPeriodos("resultado",cartDir);
 dir.estrategia=rodarPeriodos("estrategia",()=>({cartoes:cartDir(),krs:$$("#conteudo .kr").map(k=>({id:k.dataset.id,est:k.dataset.estado,valor:+k.dataset.valor,ritmo:+k.dataset.ritmo}))}));
 R.push({passo:"diretoria_periodos",dados:dir});
 // 11c. outros cliques da diretoria
 const ex={};
 clique($('#seg button[data-modo="ano"]'));
 clique($('#side .nav[data-pag="estrategia"]'));ex.estrategia_h1=$("#conteudo h1").textContent;ex.krs=$$("#conteudo .kr").length;
 $$("#conteudo .kr")[1].click();ex.kr_gaveta=$("#gaveta").classList.contains("on")&&/Como foi medido/.test($("#gaveta").textContent);ex.kr_titulo=$("#gaveta h2").textContent;$('#gaveta [data-act="fechar"]').click();
 clique($('#side .nav[data-pag="vendas"]'));ex.vendas_h1=$("#conteudo h1").textContent;
 const linhasMes=$$('#conteudo tr[data-act="irmes"]');ex.linhas_mes=linhasMes.length;
 const fotosAntes=$$("#conteudo img").length;ex.fotos_produto=fotosAntes;
 const pr=$$('#conteudo tr[data-act="item"][data-tipo="produto"]');ex.produtos=pr.length;pr[0].click();ex.prod_gaveta=$("#gaveta").classList.contains("on");ex.prod_titulo=$("#gaveta h2").textContent;ex.prod_total=+($("#gaveta [data-total-item]")||{dataset:{totalItem:-1}}).dataset.totalItem;$('#gaveta [data-act="fechar"]').click();
 const ca=$$('#conteudo tr[data-act="item"][data-tipo="canal"]');ex.canais=ca.length;ca[0].click();ex.canal_gaveta=$("#gaveta").classList.contains("on");$('#gaveta [data-act="fechar"]').click();
 const cl=$$('#conteudo tr[data-act="item"][data-tipo="cliente"]');ex.clientes=cl.length;cl[0].click();ex.cliente_gaveta=$("#gaveta").classList.contains("on");$('#gaveta [data-act="fechar"]').click();
 const bc=$('#conteudo input[data-busca="v-cli"]');bc.value="Cariri";bc.dispatchEvent(new Event("input",{bubbles:true}));ex.busca_cliente=$$('#conteudo tr[data-act="item"][data-tipo="cliente"]').length;bc.value="";bc.dispatchEvent(new Event("input",{bubbles:true}));
 $$('#conteudo [data-tab="v-prod"] th')[2].click();const o1=$('#conteudo [data-tab="v-prod"] tbody tr td:nth-child(3)').textContent;$$('#conteudo [data-tab="v-prod"] th')[2].click();const o2=$('#conteudo [data-tab="v-prod"] tbody tr td:nth-child(3)').textContent;ex.ordem_produto=[o1,o2];
 clique($('#seg button[data-modo="ano"]'));clique($('#side .nav[data-pag="vendas"]'));
 const antesMes=document.body.dataset.modo;$$('#conteudo tr[data-act="irmes"]')[5].click();ex.irmes=[antesMes,document.body.dataset.modo,document.body.dataset.periodo];
 clique($('#side .nav[data-pag="resultado"]'));ex.resultado_h1=$("#conteudo h1").textContent;ex.cat_linhas=$$("#conteudo [data-tab=r-cat] tbody tr").length;
 clique($('#side .nav[data-pag="conferencia"]'));ex.conf_dir=$$("#conteudo [data-tela-dir]").map(x=>({nome:x.dataset.telaDir,v:+x.dataset.valor,selo:x.parentElement.querySelector(".pill").textContent}));
 R.push({passo:"diretoria_cliques",dados:ex});
 // 12. imagens carregadas (espera)
 clique($('#side .nav[data-forn="polar"]'));
 setTimeout(function(){
   const im=$$("#conteudo img, #side img").map(x=>({alt:x.alt,ok:x.complete&&x.naturalWidth>0}));
   R.push({passo:"imagens",dados:im});
   R.push({passo:"erros_js",dados:erros});
   gav.msg=msgEl.textContent;
   fim();
 },1500);
 }catch(e){R.push({passo:"EXCECAO",dados:String(e.stack||e)});R.push({passo:"erros_js",dados:erros});fim()}
});
</script>
"""


def esperado(dados, modo, per):
    meses = {"mes": [per], "tri": list(range((per - 1) * 3 + 1, (per - 1) * 3 + 4)), "ano": list(range(1, 13))}[modo]
    ns = [n for n in dados["notas"] if int(n["d"][5:7]) in meses]
    return {"v": sum(n["v"] for n in ns), "li": sum(n["li"] for n in ns), "re": sum(n["re"] for n in ns), "bl": sum(n["bl"] for n in ns), "co": sum(n["co"] for n in ns)}


import calendar, datetime as dtm


def _frac(m, ref):
    ini, dim = dtm.date(2026, m, 1), calendar.monthrange(2026, m)[1]
    fim = dtm.date(2026, m, dim)
    return 1.0 if ref >= fim else 0.0 if ref < ini else ref.day / dim


def esperado_dir(dados, modo, per):
    """Esperado de Vendas, Resultado e Estratégia, recalculado aqui em Python a partir dos dados do painel (sem usar a conta do JavaScript)."""
    D = dados["dir"]
    ULT = max(dtm.date.fromisoformat(v[0]) for v in D["vendas"])
    meses = {"mes": [per], "tri": list(range((per - 1) * 3 + 1, (per - 1) * 3 + 4)), "ano": list(range(1, 13))}[modo]
    vm = lambda m: [v for v in D["vendas"] if int(v[0][5:7]) == m]
    rec = sum(v[8] for m in meses for v in vm(m))
    meta = round(sum(D["meta"][m - 1] * 100 * _frac(m, ULT) for m in meses))
    mp = sum(n["v"] for n in dados["notas"] if int(n["d"][5:7]) in meses)
    dsp = sum(x[4] for x in D["despesas"] if int(x[0][5:7]) in meses)
    orc = round(sum(o["meses"][m - 1] * _frac(m, ULT) for o in D["orc"] for m in meses))
    res = rec - mp - dsp
    out = {"vendas": {"rec": rec, "meta": meta, "dif": rec - meta, "ating": round(rec / meta * 1e4) if meta else 0},
           "resultado": {"rec": rec, "mp": mp, "desp": dsp, "orc": orc, "res": res, "marg": round(res / rec * 1e4) if rec else 0}}
    # estratégia: corte = fim do período (ou a última data dos dados)
    ult_m = max(meses)
    corte = min(dtm.date(2026, ult_m, calendar.monthrange(2026, ult_m)[1]), ULT)
    V = [v for v in D["vendas"] if v[0] <= corte.isoformat()]
    N = [n for n in dados["notas"] if n["d"] <= corte.isoformat()]
    Dp = [x for x in D["despesas"] if x[0] <= corte.isoformat()]
    r_, mp_, d_ = sum(v[8] for v in V), sum(n["v"] for n in N), sum(x[4] for x in Dp)
    metaA = sum(D["meta"][m - 1] * 100 * _frac(m, corte) for m in range(1, 13))
    orcA = sum(o["meses"][m - 1] * _frac(m, corte) for o in D["orc"] for m in range(1, 13))
    pT = corte.timetuple().tm_yday / 365
    pR = metaA / (sum(D["meta"]) * 100)
    ja = {c["cliente"] for c in D["clientes2025"]}
    novos = {v[2] for v in V if v[3] == "Atacado" and v[2] not in ja}
    K = D["okrs"]
    vals = [  # (valor, ritmo, tipo)
        (r_, metaA, "min"), ((r_ - mp_ - d_) / r_, K[1]["meta"], "min"), (d_ / orcA, K[2]["meta"], "max"),
        (sum(n["v"] for n in N if n["s"] == "liberado" and n["co"] == 0) / sum(n["v"] for n in N), K[3]["meta"], "min"),
        (sum(n["li"] for n in N if n["ql"] in ("fora", "sem_spec", "sem_laudo")), 0, "max"),
        (sum(n["co"] for n in N), K[5]["meta"] * 100 * pT, "max"),
        (sum(v[8] for v in V if "amaciante" in v[5].lower()), K[6]["meta"] * 100 * pR, "min"),
        (sum(v[8] for v in V if v[3] == "Distribuidor") / r_, K[7]["meta"], "min"),
        (len(novos), K[8]["meta"] * pT, "min")]
    krs = []
    for i, (v, rt, tp) in enumerate(vals):
        if tp == "min":
            e = "ok" if v >= rt else "atencao" if v >= 0.9 * rt else "fora"
        elif rt == 0:
            e = "ok" if v == 0 else "fora"
        else:
            e = "ok" if v <= rt else "atencao" if v <= 1.1 * rt else "fora"
        krs.append({"id": "kr%d" % (i + 1), "est": e, "valor": v, "ritmo": rt})
    out["estrategia"] = krs
    return out


def main():
    html = (RAIZ / "painel.html").read_text(encoding="utf-8")
    dados = json.loads(re.search(r"/\*DADOS\*/(.*?)/\*FIM\*/", html, re.S).group(1))
    tmp = Path(tempfile.mkdtemp()) / "painel-teste.html"
    tmp.write_text(html.replace("</body>", SCRIPT + "</body>"), encoding="utf-8")
    r = subprocess.run([CHROME, "--headless=new", "--disable-gpu", "--no-sandbox", "--virtual-time-budget=15000", "--dump-dom", tmp.as_uri()],
                       capture_output=True, text=True, timeout=120)
    m = re.search(r'<pre id="__resultado">(.*?)</pre>', r.stdout, re.S)
    if not m:
        print("O teste não terminou. Saída do Chrome:\n", r.stdout[-1500:], r.stderr[-800:]); return 2
    R = json.loads(base64.b64decode(m[1]).decode())
    falhas, linhas = 0, []
    def ok(c, texto):
        nonlocal falhas
        linhas.append(("OK     " if c else "FALHOU ") + texto); falhas += 0 if c else 1
    P = next(x for x in R if x["passo"] == "periodos")["dados"]
    vistos = set()
    for p in P:
        e = esperado(dados, p["modo"], p["per"])
        rot = {"mes": "mês %02d" % p["per"], "tri": "trimestre %d" % p["per"], "ano": "ano"}[p["modo"]]
        ok(p.get("achou", True) and p["v"] == e, "botão %-12s números da tela %s" % (rot, "= esperado (faturado %.2f)" % (e["v"] / 100) if p["v"] == e else "%s ≠ %s" % (p["v"], e)))
        vistos.add(tuple(p["v"].values()))
    ok(len(vistos) >= 12, "os botões de período mudam os números (%d conjuntos diferentes de números)" % len(vistos))
    for x in next(x for x in R if x["passo"] == "menu")["dados"]:
        ok(bool(x["h1"]) and x["pagina"] != "", "menu «%s» abre a página %s (título: %s)" % (x["rot"], x["pagina"], x["h1"]))
    for x in next(x for x in R if x["passo"] == "cartoes_levam_a_lista")["dados"]:
        ok(x["pagina"] in ("notas", "liberados", "retidos", "bloqueados", "cobrancas"), "cartão %s leva à lista %s" % (x["card"], x["pagina"]))
    b = next(x for x in R if x["passo"] == "busca_e_ordem")["dados"]
    ok(b["depois"] == 1 and b["primeiraLinhaTemNota8851"] and b["volta"] == b["antes"], "busca '8851': %d linhas → %d (nota 8851) → limpa e volta a %d" % (b["antes"], b["depois"], b["volta"]))
    ok(b["menorOuMaior"][0] != b["menorOuMaior"][1], "clicar no título da coluna ordena (%s ↔ %s)" % tuple(b["menorOuMaior"]))
    g = next(x for x in R if x["passo"] == "gaveta")["dados"]
    ok(g["aberta"] and g["fechada"] and "Copiado" in g["msg"], "clicar numa nota abre o detalhe (%s), «Copiar pedido da carta» copia, ✕ fecha" % g["titulo"])
    for x in next(x for x in R if x["passo"] == "fornecedores")["dados"]:
        ok(x["pagina"].startswith("f:") and len(x["imgs"]) == 2 and x["linhas"] >= 0 and x["cartoes"], "fornecedor %s abre a página dele (%s; foto+logo; %d notas no mês)" % (x["botao"], x["h1"], x["linhas"]))
    for x in next(x for x in R if x["passo"] == "analise_linha_abre_fornecedor")["dados"]:
        ok(x["pagina"] == x["esperado"], "análise: linha abre %s" % x["esperado"])
    for x in next(x for x in R if x["passo"] == "filtros_fazer")["dados"]:
        ok(True, "o que fazer, filtro «%s»: %d linhas" % (x["chip"], x["linhas"]))
    c = next(x for x in R if x["passo"] == "conferencia")["dados"]
    tela_ano = sum(n["v"] for n in dados["notas"])
    ok(c["total"] == tela_ano and all(p in ("Bate", "Tudo bate") for p in c["pills"]), "conferência na tela: total %.2f, selos %s" % ((c["total"] or 0) / 100, set(c["pills"])))
    bg = next(x for x in R if x["passo"] == "busca_global")["dados"]
    ok(bg["pagina"] == "notas" and bg["linhas"] == 1, "busca do cabeçalho (1571) abre Todas as notas com %d linha" % bg["linhas"])
    ok(next(x for x in R if x["passo"] == "ver_todas_pendencias")["dados"] == "fazer", "«Ver todas as pendências» abre O que fazer")
    ok(next(x for x in R if x["passo"] == "botao_menu")["dados"] is True, "botão do menu (celular) abre o menu lateral")
    if "dir" in dados:
        DP = next(x for x in R if x["passo"] == "diretoria_periodos")["dados"]
        for pag in ("vendas", "resultado", "estrategia"):
            bons = 0
            for p in DP[pag]:
                e = esperado_dir(dados, p["modo"], p["per"])[pag]
                rot = {"mes": "mês %02d" % p["per"], "tri": "trimestre %d" % p["per"], "ano": "ano"}[p["modo"]]
                if pag != "estrategia":
                    certo = all(abs(p["v"][k] - e[k]) <= 1 for k in e)
                    det = "" if certo else " %s ≠ %s" % (p["v"], e)
                else:
                    cont = {"ok": 0, "atencao": 0, "fora": 0}
                    certo = len(p["v"]["krs"]) == 9
                    for got, ex_ in zip(p["v"]["krs"], e):
                        cont[ex_["est"]] += 1
                        tol = 1 if abs(ex_["valor"]) > 100 else 1e-6
                        certo = certo and got["est"] == ex_["est"] and abs(got["valor"] - ex_["valor"]) <= tol and abs(got["ritmo"] - ex_["ritmo"]) <= max(tol, 1e-6 * abs(ex_["ritmo"]))
                    certo = certo and all(p["v"]["cartoes"][k] == cont[k] for k in cont)
                    det = "" if certo else " esperado %s, tela %s" % ([(k["id"], k["est"]) for k in e], [(k["id"], k["est"]) for k in p["v"]["krs"]])
                ok(certo, "página %s · botão %-12s = esperado%s" % (pag, rot, det))
        X = next(x for x in R if x["passo"] == "diretoria_cliques")["dados"]
        ok(X["krs"] == 9 and X["kr_gaveta"], "Estratégia: 9 resultados-chave; clicar em um abre «Como foi medido» (%s)" % X["kr_titulo"])
        ok(X["linhas_mes"] == 12, "Vendas e metas: tabela mês a mês com 12 linhas clicáveis")
        ok(X["produtos"] == 6 and X["fotos_produto"] >= 6, "Vendas e metas: 6 produtos, cada um com foto (%d imagens na página)" % X["fotos_produto"])
        ok(X["prod_gaveta"] and X["prod_total"] > 0, "clicar num produto abre o detalhe (%s, receita do ano %.2f)" % (X["prod_titulo"], X["prod_total"] / 100))
        ok(X["canais"] == 3 and X["canal_gaveta"], "clicar num canal abre o detalhe (%d canais)" % X["canais"])
        ok(X["clientes"] >= 8 and X["cliente_gaveta"], "clicar num cliente abre o detalhe (%d clientes)" % X["clientes"])
        ok(X["busca_cliente"] == 1, "busca 'Cariri' na tabela de clientes deixa 1 linha")
        ok(X["ordem_produto"][0] != X["ordem_produto"][1], "ordenar produtos pela receita inverte a ordem (%s ↔ %s)" % tuple(X["ordem_produto"]))
        ok(X["irmes"][0] == "ano" and X["irmes"][1] == "mes", "clicar num mês da tabela abre o mês (%s)" % X["irmes"][2])
        ok(X["cat_linhas"] == 8, "Resultado: despesas contra o orçamento em 8 categorias")
        soma_v = sum(v[8] for v in dados["dir"]["vendas"]); soma_d = sum(x[4] for x in dados["dir"]["despesas"])
        ok(len(X["conf_dir"]) == 2 and X["conf_dir"][0]["v"] == soma_v and X["conf_dir"][1]["v"] == soma_d and all(c["selo"] == "Bate" for c in X["conf_dir"]),
           "Conferência na tela: receita %.2f e despesas %.2f, selos Bate" % (soma_v / 100, soma_d / 100))
    im = next(x for x in R if x["passo"] == "imagens")["dados"]
    ok(all(i["ok"] for i in im) and len(im) >= 7, "%d imagens (logos e foto) carregadas sem internet" % len(im))
    er = next(x for x in R if x["passo"] == "erros_js")["dados"]
    ok(not er, "nenhum erro de JavaScript" + ("" if not er else ": %s" % er))
    print("\n".join(linhas))
    print("\n%d verificações, %d falhas." % (len(linhas), falhas))
    return 1 if falhas else 0


if __name__ == "__main__":
    sys.exit(main())
