#!/usr/bin/env python3
"""Números do mês para o resumo da diretoria. Uso:  python3 programa/resumo.py AAAA-MM   (ou  ano)
Escreve resumos/numeros-AAAA-MM.md com os números; o texto de leitura quem escreve é o Claude, a partir dele."""
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
import cruzar as C

RAIZ = Path(__file__).resolve().parent.parent


def brl(c):
    return "R$ " + f"{c / 100:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def main():
    per = sys.argv[1] if len(sys.argv) > 1 else "ano"
    notas = json.loads((RAIZ / "historico" / "notas.json").read_text(encoding="utf-8"))
    laudos = json.loads((RAIZ / "historico" / "laudos.json").read_text(encoding="utf-8"))
    res = C.cruzar(notas, laudos, C.ler_pedidos(RAIZ), C.ler_specs(RAIZ))
    sel = [r for r in res if per == "ano" or r["data"].startswith(per)]
    if not sel:
        sys.exit("Nenhuma nota em %s." % per)
    T = lambda xs, k: sum(x[k] for x in xs)
    L = ["# Números do período %s" % per, "",
         "- Notas: %d" % len(sel), "- Faturado: %s" % brl(T(sel, "valor_c")), "- Liberado para pagar: %s" % brl(T(sel, "liberado_c")),
         "- Retido: %s" % brl(T(sel, "retido_c")), "- Bloqueado: %s" % brl(T(sel, "bloqueado_c")), "- Cobrado a mais: %s" % brl(T(sel, "cobrado_c")), "",
         "## Por fornecedor", "", "| Fornecedor | Notas | Faturado | Liberado | Retido | Bloqueado | Cobrado a mais |", "|---|---|---|---|---|---|---|"]
    for f in sorted({r["fornecedor"] for r in sel}):
        x = [r for r in sel if r["fornecedor"] == f]
        L.append("| %s | %d | %s | %s | %s | %s | %s |" % (f, len(x), brl(T(x, "valor_c")), brl(T(x, "liberado_c")), brl(T(x, "retido_c")), brl(T(x, "bloqueado_c")), brl(T(x, "cobrado_c"))))
    L += ["", "## Notas que pedem decisão", ""]
    for r in sel:
        if r["status"] != "liberado" or r["cobrado_c"]:
            L.append("- %s, nota %s (%s), %s, %s: %s" % (r["fornecedor"], r["nota"], r["data"][8:] + "/" + r["data"][5:7], r["status"], brl(r["valor_c"]), "; ".join(r["motivos"])))
    rep = json.loads((RAIZ / "historico" / "repetidas.json").read_text(encoding="utf-8")) if (RAIZ / "historico" / "repetidas.json").exists() else []
    rep = [r for r in rep if per == "ano" or (r["data"] or "").startswith(per)]
    if rep:
        L += ["", "## Notas repetidas (não entram no faturado)", ""] + ["- %s, nota %s, %s" % (r["fornecedor"], r["nota"], brl(round(r["valor"] * 100))) for r in rep]
    out = RAIZ / "resumos" / ("numeros-%s.md" % per)
    out.parent.mkdir(exist_ok=True)
    out.write_text("\n".join(L) + "\n", encoding="utf-8")
    print("\n".join(L)); print("\n(salvo em %s)" % out.relative_to(RAIZ))


if __name__ == "__main__":
    main()
