#!/usr/bin/env python3
"""A conferência: o total das notas na TELA (painel.html) contra o total dos ARQUIVOS, por fornecedor.
Os arquivos são relidos aqui por um caminho próprio (só somam a coluna de valor), sem usar o leitor do programa.
Uso:  python3 programa/conferir.py"""
import json, re, sys
from pathlib import Path
import openpyxl, csv

FORNEC = ["Aromas", "Brisamar", "Carnauba", "Polar", "Quimisol"]


def _n(x):
    if isinstance(x, (int, float)):
        return float(x)
    s = re.sub(r"[^\d,.]", "", str(x))
    if "," in s:
        s = s.replace(".", "").replace(",", ".")
    return float(s) if s else None


def _linhas_xlsx(p):
    wb = openpyxl.load_workbook(p, data_only=True)
    for ws in wb.worksheets:
        if re.search(r"observ|uso interno", ws.title, re.I):
            continue
        yield from ws.iter_rows(values_only=True)


def _linhas_csv(p):
    raw = p.read_bytes()
    try:
        txt = raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        txt = raw.decode("cp1252")
    yield from csv.reader(txt.splitlines(), delimiter=";" if txt.count(";") > txt.count(",") else ",")


def somar_arquivo(p):
    """Soma independente: acha a coluna de valor pelo cabeçalho e soma uma linha por nota fiscal."""
    linhas = list(_linhas_xlsx(p) if p.suffix.lower() == ".xlsx" else _linhas_csv(p))
    soma, qtd, col, ncol, declarados = 0.0, 0, None, None, []
    vistos = []
    for l in linhas:
        cel = [str(c).strip().lower() if c is not None else "" for c in l]
        if any(re.match(r"^(valor|total|vlr total|valor total)", c) for c in cel) and any(re.match(r"^(nota|nf|n. nf|nº nf)", c) for c in cel):
            col = max(i for i, c in enumerate(cel) if re.match(r"^(valor|total|vlr total|valor total)", c))
            ncol = next(i for i, c in enumerate(cel) if re.match(r"^(nota|nf|n. nf|nº nf)", c))
            continue
        if col is None:
            continue
        txt = " ".join(str(c) for c in l if c)
        m = re.search(r"total.*?([\d.]+,\d{2})", txt, re.I)
        if m and not re.fullmatch(r"\D*\d+\D*", str(l[ncol] or "")):
            declarados.append(_n(m[1])); continue
        if col < len(l) and l[col] not in (None, "") and ncol < len(l) and re.search(r"\d", str(l[ncol] or "")):
            soma += _n(l[col]); qtd += 1
            vistos.append((re.sub(r"\D", "", str(l[ncol])), _n(l[col])))
    return {"soma": round(soma, 2), "linhas": qtd, "declarados": declarados, "vistos": vistos}


def somar_diretoria(p, tipo):
    """Soma independente de Vendas ou Despesas: acha a coluna 'Valor' pelo cabeçalho e soma toda linha que começa com data."""
    import datetime as dt
    linhas = list(_linhas_xlsx(p))
    col = ncol = None
    soma, qtd, vistos, rep, rep_n = 0.0, 0, set(), 0.0, 0
    por_mes = {}
    for l in linhas:
        cel = [str(c).strip().lower() if c is not None else "" for c in l]
        if col is None and any(c.startswith("data") for c in cel) and any(c.startswith("valor") for c in cel):
            col = max(i for i, c in enumerate(cel) if c.startswith("valor"))
            ncol = next((i for i, c in enumerate(cel) if re.match(r"^(nf|nota)", c)), None)
            continue
        if col is None or not isinstance(l[0], dt.datetime) or l[col] in (None, ""):
            continue
        v = _n(l[col])
        chave = str(l[ncol]).strip() if (tipo == "vendas" and ncol is not None) else (l[0], l[2] if len(l) > 2 else None, l[3] if len(l) > 3 else None, v)
        if chave in vistos:
            rep += v; rep_n += 1; continue
        vistos.add(chave)
        soma += v; qtd += 1
        por_mes[l[0].month] = por_mes.get(l[0].month, 0.0) + v
    return {"soma": round(soma, 2), "linhas": qtd, "rep_valor": round(rep, 2), "rep_n": rep_n, "por_mes": por_mes}


def verificar_diretoria(raiz, dados):
    out = []
    if "dir" not in dados:
        return out
    for tipo, rot, chave in (("vendas", "Receita (vendas)", "vendas"), ("despesas", "Despesas", "despesas")):
        soma, qtd, rep, arqs, pm = 0.0, 0, 0.0, [], {}
        for p in sorted((Path(raiz) / "arquivos-lidos").rglob("*.xlsx")):
            if p.name.lower().startswith(tipo):
                r = somar_diretoria(p, tipo)
                soma += r["soma"]; qtd += r["linhas"]; rep += r["rep_valor"]; arqs.append(p.name)
                for m, v in r["por_mes"].items():
                    pm[m] = pm.get(m, 0.0) + v
        linhas = dados["dir"][chave]
        idx = 8 if tipo == "vendas" else 4
        tela = round(sum(l[idx] for l in linhas) / 100, 2)
        ok = abs(tela - round(soma, 2)) < 0.005 and len(linhas) == qtd
        # o mesmo, mês a mês (jan a dez)
        meses_ok = all(abs(round(sum(l[idx] for l in linhas if int(l[0][5:7]) == m) / 100, 2) - round(pm.get(m, 0.0), 2)) < 0.005 for m in range(1, 13))
        out.append({"nome": rot, "arquivos": arqs, "linhas_nos_arquivos": qtd, "total_arquivos": round(soma, 2), "linhas_tela": len(linhas), "total_tela": tela,
                    "diferenca": round(tela - soma, 2), "mes_a_mes_ok": meses_ok, "ok": ok and meses_ok})
    return out


def verificar(raiz):
    raiz = Path(raiz)
    painel = (raiz / "painel.html").read_text(encoding="utf-8")
    dados = json.loads(re.search(r"/\*DADOS\*/(.*?)/\*FIM\*/", painel, re.S).group(1))
    arquivos = sorted(p for p in (raiz / "arquivos-lidos").rglob("*") if p.is_file() and re.search(r"\bnotas?\b", p.name, re.I))
    por = {f: {"fornecedor": f, "arquivos": [], "linhas": 0, "soma_arquivos": 0.0, "declarado": 0.0, "vistos": []} for f in FORNEC}
    for p in arquivos:
        f = next((f for f in FORNEC if p.name.lower().startswith(f.lower())), None)
        if not f:
            continue
        r = somar_arquivo(p)
        d = por[f]
        d["arquivos"].append(p.name); d["linhas"] += r["linhas"]; d["soma_arquivos"] += r["soma"]
        d["declarado"] += sum(r["declarados"]); d["vistos"] += r["vistos"]
    linhas = []
    tudo = True
    for f in FORNEC:
        d = por[f]
        # repetições: a mesma nota (mesmo número) vista mais de uma vez nos arquivos
        vistos, rep_valor, rep_n = {}, 0.0, 0
        for n, v in d["vistos"]:
            if n in vistos:
                rep_valor += v; rep_n += 1
            else:
                vistos[n] = v
        esperado = round(d["soma_arquivos"] - rep_valor, 2)
        notas_tela = [n for n in dados["notas"] if n["f"].lower() == f.lower()]
        tela = round(sum(n["v"] for n in notas_tela) / 100, 2)
        ids = [n["n"] for n in notas_tela]
        unica = len(ids) == len(set(ids))
        ok = abs(tela - esperado) < 0.005 and unica and len(notas_tela) == len(vistos)
        tudo &= ok
        linhas.append({"fornecedor": f, "arquivos": d["arquivos"], "linhas_nos_arquivos": d["linhas"], "total_arquivos": round(d["soma_arquivos"], 2),
                       "repeticoes_n": rep_n, "repeticoes_valor": round(rep_valor, 2), "total_esperado": esperado,
                       "notas_tela": len(notas_tela), "total_tela": tela, "diferenca": round(tela - esperado, 2), "cada_nota_uma_vez": unica,
                       "total_declarado_pelo_fornecedor": round(d["declarado"], 2) if d["declarado"] else None, "ok": ok})
    dire = verificar_diretoria(raiz, dados)
    tudo = tudo and all(d["ok"] for d in dire)
    return {"linhas": linhas, "diretoria": dire, "tudo_bate": tudo,
            "totais": {k: round(sum(l[k] for l in linhas), 2) for k in ("total_arquivos", "repeticoes_valor", "total_esperado", "total_tela")}}


def _m(v):
    return "R$ " + f"{v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def texto_conferencia(c):
    t = ["CONFERÊNCIA · total nos arquivos x total na tela (painel.html)", "",
         "%-9s %7s %17s %8s %17s %7s %17s %9s" % ("Fornec.", "Linhas", "Total arquivos", "Repet.", "Esperado", "Notas", "Total na tela", "Diferença")]
    for l in c["linhas"]:
        t.append("%-9s %7d %17s %8s %17s %7d %17s %9s  %s" % (l["fornecedor"], l["linhas_nos_arquivos"], _m(l["total_arquivos"]),
                 "-" + _m(l["repeticoes_valor"]) if l["repeticoes_n"] else "0", _m(l["total_esperado"]), l["notas_tela"], _m(l["total_tela"]),
                 _m(l["diferenca"]), "OK" if l["ok"] else "NÃO BATE"))
    x = c["totais"]
    t.append("%-9s %7s %17s %8s %17s %7s %17s" % ("TOTAL", "", _m(x["total_arquivos"]), "", _m(x["total_esperado"]), "", _m(x["total_tela"])))
    if c.get("diretoria"):
        t.append("")
        t.append("%-18s %8s %17s %8s %17s %10s" % ("Visão da diretoria", "Linhas", "Total arquivos", "Linhas", "Total na tela", "Resultado"))
        for d in c["diretoria"]:
            t.append("%-18s %8d %17s %8d %17s %10s  mês a mês: %s" % (d["nome"], d["linhas_nos_arquivos"], _m(d["total_arquivos"]), d["linhas_tela"], _m(d["total_tela"]),
                     "OK" if d["ok"] else "NÃO BATE", "bate" if d["mes_a_mes_ok"] else "NÃO bate"))
    decl = [l for l in c["linhas"] if l["total_declarado_pelo_fornecedor"]]
    for l in decl:
        t.append("Contraprova: a Carnaúba escreve o total de cada mês no próprio arquivo; somados dão %s (as linhas dão %s)." % (_m(l["total_declarado_pelo_fornecedor"]), _m(l["total_arquivos"])))
    t.append("")
    t.append("RESULTADO: " + ("o total da tela bate com o dos arquivos, e cada nota aparece uma vez só." if c["tudo_bate"] else "NÃO BATE: veja as linhas marcadas."))
    return "\n".join(t)


def escrever_relatorio(raiz, c):
    (Path(raiz) / "conferencia.txt").write_text(texto_conferencia(c) + "\n", encoding="utf-8")


if __name__ == "__main__":
    raiz = Path(__file__).resolve().parent.parent
    c = verificar(raiz)
    print(texto_conferencia(c))
    sys.exit(0 if c["tudo_bate"] else 2)
