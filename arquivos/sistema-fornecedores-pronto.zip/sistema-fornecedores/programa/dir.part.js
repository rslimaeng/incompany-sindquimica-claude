/* ================= visão da diretoria: Estratégia, Vendas e metas, Resultado ================= */
const DIR=D.dir||null;
const ult=a=>a.reduce((m,x)=>x>m?x:m,"");
const ULT=DIR?ult(DIR.vendas.map(v=>v[0])):"";
const ULT_NOTA=ult(D.notas.map(n=>n.d)), ULT_DESP=DIR&&DIR.despesas.length?ult(DIR.despesas.map(x=>x[0])):"";
const dim=m=>new Date(D.ano,m,0).getDate();
const iso=(m,d)=>D.ano+"-"+String(m).padStart(2,"0")+"-"+String(d).padStart(2,"0");
function fracM(m,ref){if(ref>=iso(m,dim(m)))return 1;if(ref<iso(m,1))return 0;return +ref.slice(8,10)/dim(m)}
const mesesPer=()=>S.modo==="ano"?[1,2,3,4,5,6,7,8,9,10,11,12]:S.modo==="tri"?[0,1,2].map(i=>(S.tri-1)*3+1+i):[S.mes];
const dmy=iso=>iso.slice(8,10)+"/"+iso.slice(5,7);
const pc=(x,d=1)=>(x*100).toFixed(d).replace(".",",")+" %";
const normS=s=>String(s).normalize("NFD").replace(/[̀-ͯ]/g,"").toLowerCase();
function fotoDe(prod){if(!DIR)return "";const n=normS(prod);for(const k in DIR.fotos){if(k.split("-").every(w=>n.includes(w)))return DIR.fotos[k]}return ""}
const vend=(ini,fim)=>DIR.vendas.filter(v=>v[0]>=ini&&v[0]<=fim);
const desp=(ini,fim)=>DIR.despesas.filter(v=>v[0]>=ini&&v[0]<=fim);
const sv=a=>a.reduce((s,x)=>s+x[8],0), sd=a=>a.reduce((s,x)=>s+x[4],0);
const metaPer=(meses,ref)=>Math.round(meses.reduce((s,m)=>s+DIR.meta[m-1]*100*fracM(m,ref),0));
const orcLinha=(o,meses,ref)=>meses.reduce((s,m)=>s+o.meses[m-1]*fracM(m,ref),0);
const orcPer=(meses,ref)=>Math.round(DIR.orc.reduce((s,o)=>s+orcLinha(o,meses,ref),0));
function pilulaPct(r){return r<=1?'<span class="pill ok">'+pc(r)+'</span>':r<=1.1?'<span class="pill warn">'+pc(r)+'</span>':'<span class="pill bad">'+pc(r)+'</span>'}
function cartoesGen(defs,cls){return `<div class="nums ${cls||""}">${defs.map(d=>`<div class="num" data-card="${d.k}" data-valor="${d.v}" style="cursor:default"><div class="rot"><span class="pt" style="background:${d.c}"></span>${d.r}</div><div class="big">${d.pct?pc(d.v/1e4,1):abrev(d.v)}</div><div class="cheio">${d.pct?(d.sub||""):brl(d.v)+(d.sub?" · "+d.sub:"")}</div>${d.badge||""}</div>`).join("")}</div>`}
function semDados(){return `<div class="vazio-msg">Sem dados neste período.</div>`}

/* ---------- Estratégia ---------- */
function corteKR(){
 const m=mesesPer(),ultimoM=Math.max(...m);let c=iso(ultimoM,dim(ultimoM));return c>ULT?ULT:c}
function medirKRs(corte){
 const R=vend("0000",corte),Dd=desp("0000",corte),N=D.notas.filter(n=>n.d<=corte);
 const rec=sv(R),mp=soma(N,"v"),dsp=sd(Dd),tv=soma(N,"v");
 const mesesAte=[1,2,3,4,5,6,7,8,9,10,11,12];
 const orcA=orcPer(mesesAte,corte),metaA=metaPer(mesesAte,corte),metaAno=Math.round(DIR.meta.reduce((a,b)=>a+b,0)*100);
 const doy=(new Date(corte+"T00:00:00Z")-new Date(D.ano+"-01-01T00:00:00Z"))/864e5+1,pT=doy/365,pR=metaA/metaAno;
 const jaClientes=new Set(DIR.clientes2025.map(c=>c.cliente));
 const novos=[...new Set(R.filter(v=>v[3]==="Atacado"&&!jaClientes.has(v[2])).map(v=>v[2]))];
 const liberadoSemAjuste=N.filter(n=>n.s==="liberado"&&n.co===0).reduce((a,n)=>a+n.v,0);
 const reprovPago=N.filter(n=>["fora","sem_spec","sem_laudo"].includes(n.ql)).reduce((a,n)=>a+n.li,0);
 const cobr=soma(N,"co"),amac=R.filter(v=>normS(v[5]).includes("amaciante")).reduce((a,v)=>a+v[8],0);
 const dist=R.filter(v=>v[3]==="Distribuidor").reduce((a,v)=>a+v[8],0);
 const res=rec-mp-dsp;
 const K=DIR.okrs,def=[
  {tipo:"min",fmt:"brl",valor:rec,ritmo:Math.round(metaA),meta:K[0].meta*100,como:"Soma das vendas de 1/1 a "+dmy(corte)+". Ritmo = meta de receita acumulada até a data ("+brl(Math.round(metaA))+", com o mês corrente proporcional aos dias)."},
  {tipo:"min",fmt:"pct",valor:rec?res/rec:0,ritmo:K[1].meta,meta:K[1].meta,como:"(receita − matéria-prima − despesas) ÷ receita, de 1/1 a "+dmy(corte)+". Receita "+brl(rec)+", matéria-prima (notas dos fornecedores) "+brl(mp)+", despesas "+brl(dsp)+". Ritmo = a própria meta."},
  {tipo:"max",fmt:"pct",valor:orcA?dsp/orcA:0,ritmo:K[2].meta,meta:K[2].meta,como:"Despesas realizadas "+brl(dsp)+" ÷ orçamento do mesmo período "+brl(orcA)+" (mês corrente proporcional aos dias)."},
  {tipo:"min",fmt:"pct",valor:tv?liberadoSemAjuste/tv:0,ritmo:K[3].meta,meta:K[3].meta,como:"Valor das notas liberadas sem nenhum ajuste (preço, quantidade, qualidade ou pedido) "+brl(liberadoSemAjuste)+" ÷ valor faturado "+brl(tv)+"."},
  {tipo:"max",fmt:"brl",valor:reprovPago,ritmo:0,meta:0,como:"Valor liberado para pagar de lotes fora da especificação, sem especificação ou sem laudo. Hoje o sistema os retém, então o valor liberado deles é "+brl(reprovPago)+"."},
  {tipo:"max",fmt:"brl",valor:cobr,ritmo:Math.round(K[5].meta*100*pT),meta:K[5].meta*100,como:"Soma do cobrado a mais nas notas dos fornecedores até "+dmy(corte)+". O limite do ano é "+brl(K[5].meta*100)+"; o ritmo é esse limite proporcional ao tempo ("+pc(pT)+" do ano)."},
  {tipo:"min",fmt:"brl",valor:amac,ritmo:Math.round(K[6].meta*100*pR),meta:K[6].meta*100,como:"Soma das vendas do Amaciante 2 L. Ritmo = meta × a fração da meta de receita acumulada ("+pc(pR)+")."},
  {tipo:"min",fmt:"pct",valor:rec?dist/rec:0,ritmo:K[7].meta,meta:K[7].meta,como:"Receita do canal Distribuidor "+brl(dist)+" ÷ receita total "+brl(rec)+". Ritmo = a própria meta."},
  {tipo:"min",fmt:"n",valor:novos.length,ritmo:K[8].meta*pT,meta:K[8].meta,como:"Clientes do canal Atacado que não estão na aba Clientes em 2025: "+(novos.length?novos.join(", "):"nenhum")+". Ritmo = a meta proporcional ao tempo ("+pc(pT)+" do ano)."}];
 return def.map((d,i)=>{const k=K[i];let est;
  if(d.tipo==="min"){const r=d.ritmo?d.valor/d.ritmo:1;est=r>=1?"ok":r>=.9?"atencao":"fora"}
  else{if(d.ritmo===0)est=d.valor===0?"ok":"fora";else{const r=d.valor/d.ritmo;est=r<=1?"ok":r<=1.1?"atencao":"fora"}}
  return Object.assign({i,id:"kr"+(i+1),obj:k.objetivo,nome:k.kr,resp:k.resp,est,unidade:k.unidade},d)})}
const ESTR={ok:["ok","No ritmo"],atencao:["warn","Atenção"],fora:["bad","Fora do ritmo"]};
function fk(k,v){return k.fmt==="brl"?brl(Math.round(v)):k.fmt==="pct"?pc(v):String(Math.round(v*10)/10).replace(".",",")}
function pEstrategia(){
 const corte=corteKR(),K=medirKRs(corte),p=periodo();
 const cont={ok:0,atencao:0,fora:0};K.forEach(k=>cont[k.est]++);
 const objs=[...new Set(K.map(k=>k.obj))];
 const aviso=p.curto&&mesesPer().every(m=>iso(m,1)>ULT)?`<div class="caixa warn">Sem dados em ${esc(p.rot)}. Mostrando a posição até ${dbr(ULT)}, a última data dos dados.</div>`:"";
 return `<h1>Estratégia · ${esc(p.curto)}</h1><p class="lede">Cada resultado-chave dos OKRs, medido do início do ano até <b>${dbr(corte)}</b>, contra o ritmo esperado nessa data. Clique em um resultado-chave para ver como foi medido.</p>${aviso}
 ${cartoesGen([{k:"ok",r:"No ritmo",v:cont.ok,c:COR.li},{k:"atencao",r:"Atenção",v:cont.atencao,c:COR.co},{k:"fora",r:"Fora do ritmo",v:cont.fora,c:COR.re},{k:"total",r:"Resultados-chave",v:K.length,c:COR.fat}].map(x=>({k:x.k,r:x.r,v:x.v*1e4,c:x.c,pct:0,sub:"",bigtxt:1})),"n4 contagem")}
 ${objs.map(o=>`<section class="cartao" style="margin-bottom:24px"><h3>${esc(o)}</h3><p class="leg">${esc(K.find(k=>k.obj===o).nome?"":"")}</p>${K.filter(k=>k.obj===o).map(k=>{const max=Math.max(k.meta,k.valor,k.ritmo)||1,w=Math.min(100,k.valor/max*100),mk=k.ritmo/max*100,cor=k.est==="ok"?COR.li:k.est==="atencao"?COR.co:COR.re;
  return `<button class="kr" data-act="kr" data-id="${k.id}" data-estado="${k.est}"><div class="kr-t"><b>${esc(k.nome)}</b><span class="pill ${ESTR[k.est][0]}">${ESTR[k.est][1]}</span></div><div class="kr-n"><span>Realizado <b>${fk(k,k.valor)}</b></span><span>Ritmo esperado <b>${fk(k,k.ritmo)}</b></span><span>Meta do ano <b>${k.tipo==="max"?"no máximo ":""}${fk(k,k.meta)}</b></span></div><div class="barra" style="height:8px;position:relative;overflow:visible"><span style="width:${w}%;background:${cor};border-radius:99px"></span><i style="position:absolute;left:${Math.min(99.5,mk)}%;top:-4px;width:2px;height:16px;background:#0F172A"></i></div><div class="leg" style="margin:6px 0 0">${esc(k.resp)}</div></button>`}).join("")}</section>`).join("")}`}

/* ---------- Vendas e metas ---------- */
function pVendas(){
 const p=periodo(),M=mesesPer(),V=vend(p.ini,p.fim),rec=sv(V),meta=metaPer(M,ULT),dif=rec-meta,ating=meta?rec/meta:0;
 const mes12=[];for(let m=1;m<=12;m++){const x=vend(iso(m,1),iso(m,31));mes12.push({m,rec:sv(x),meta:Math.round(DIR.meta[m-1]*100*fracM(m,ULT)),metaCheia:DIR.meta[m-1]*100,no:M.includes(m)})}
 const porProd=aggr(V,v=>v[5],v=>({foto:v[5],un:v[6]})),porCanal=aggr(V,v=>v[3]),porCli=aggr(V,v=>v[2],v=>({canal:v[3]}));
 const ja=new Set(DIR.clientes2025.map(c=>c.cliente));
 reg("v-mes",mes12,[{t:"Mês",f:r=>`<b>${MESES[r.m-1]}</b>${r.no?' <span class="pill ok">no período</span>':""}`,s:r=>r.m},{t:"Receita",d:1,f:r=>brl(r.rec),s:r=>r.rec},{t:"Meta",d:1,f:r=>brl(r.meta)+(r.meta!==r.metaCheia&&r.meta>0?"*":""),s:r=>r.meta},{t:"Receita ÷ meta",d:1,f:r=>r.meta?pilulaMeta(r.rec/r.meta):"—",s:r=>r.meta?r.rec/r.meta:0}],{acao:"mes"});
 reg("v-prod",porProd,[{t:"Produto",f:r=>`<span style="display:flex;gap:12px;align-items:center"><img src="${fotoDe(r.k)}" alt="Foto ${esc(r.k)}" style="width:44px;height:44px;border-radius:10px;object-fit:cover;border:1px solid var(--line)"><b>${esc(r.k)}</b></span>`,s:r=>r.k},{t:"Unidades",d:1,f:r=>r.un.toLocaleString("pt-BR"),s:r=>r.un},{t:"Receita",d:1,f:r=>brl(r.v),s:r=>r.v},{t:"% da receita",d:1,f:r=>rec?pc(r.v/rec):"—",s:r=>r.v}],{acao:"item",tipo:"produto"});
 reg("v-canal",porCanal,[{t:"Canal",f:r=>`<b>${esc(r.k)}</b>`,s:r=>r.k},{t:"Receita",d:1,f:r=>brl(r.v),s:r=>r.v},{t:"% da receita",d:1,f:r=>rec?pc(r.v/rec,2):"—",s:r=>r.v}],{acao:"item",tipo:"canal"});
 reg("v-cli",porCli,[{t:"Cliente",f:r=>`<b>${esc(r.k)}</b>${ja.has(r.k)?"":' <span class="pill warn">novo em 2026</span>'}`,s:r=>r.k},{t:"Canal",f:r=>esc(r.canal),s:r=>r.canal},{t:"Receita",d:1,f:r=>brl(r.v),s:r=>r.v},{t:"% da receita",d:1,f:r=>rec?pc(r.v/rec):"—",s:r=>r.v}],{acao:"item",tipo:"cliente"});
 const tem=V.length>0;
 return `<h1>Vendas e metas · ${esc(p.curto)}</h1><p class="lede">Receita das vendas contra a meta de receita, mês a mês, por produto, por canal e por cliente. A meta do mês corrente vale até ${dbr(ULT)} (proporcional aos dias).</p>
 ${cartoesGen([{k:"rec",r:"Receita",v:rec,c:COR.li},{k:"meta",r:"Meta do período",v:meta,c:COR.cmp},{k:"dif",r:"Receita menos meta",v:dif,c:dif>=0?COR.li:COR.re},{k:"ating",r:"Receita ÷ meta",v:Math.round(ating*1e4),c:COR.fat,pct:1,sub:"da meta do período"}])}
 <div class="grade">
  <section class="cartao c12"><h3>Receita contra a meta, mês a mês</h3><p class="leg">Barras: receita. Linha tracejada: meta do mês. Os meses do período selecionado ficam em destaque.</p>${receitaMeta(mes12)}</section>
  <section class="cartao c12"><h3>Mês a mês</h3>${tabela("v-mes",mes12,[])}<p class="leg" style="margin:10px 0 0">* meta proporcional aos dias até ${dbr(ULT)}. Clique em um mês para abrir o período dele.</p></section>
  <section class="cartao c12"><h3>Por produto</h3><p class="leg">Receita do período ${tem?"":"(sem vendas)"}</p>${tem?tabela("v-prod",porProd,[]):semDados()}</section>
  <section class="cartao c5"><h3>Por canal</h3><p class="leg">Meta do canal Distribuidor: 25 % da receita</p>${tem?barrasHg(porCanal.map(c=>({rot:c.k,v:c.v,txt:pc(c.v/rec,2)})),COR.fat)+tabela("v-canal",porCanal,[]):semDados()}</section>
  <section class="cartao c7"><h3>Por cliente</h3><p class="leg">Quem comprou no período</p>${tem?tabela("v-cli",porCli,[]):semDados()}</section>
 </div>`}
function aggr(rows,key,extra){const m={};rows.forEach(r=>{const k=key(r);const o=m[k]||(m[k]=Object.assign({k,v:0,un:0},extra?extra(r):{}));o.v+=r[8];o.un+=r[6]||0});return Object.values(m).sort((a,b)=>b.v-a.v)}
function pilulaMeta(r){return r>=1?'<span class="pill ok">'+pc(r)+'</span>':r>=.95?'<span class="pill warn">'+pc(r)+'</span>':'<span class="pill bad">'+pc(r)+'</span>'}
function barrasHg(it,cor){const mx=Math.max(1,...it.map(i=>i.v));return `<div style="margin-bottom:14px">${it.map(i=>`<div style="display:grid;grid-template-columns:96px 1fr 70px;gap:10px;align-items:center;padding:5px 0" data-tip="${esc(i.rot)}|${brl(i.v)}"><span>${esc(i.rot)}</span><span class="barra" style="margin:0;height:10px"><span style="width:${i.v/mx*100}%;background:${cor};border-radius:99px"></span></span><b style="text-align:right;font-weight:600">${i.txt}</b></div>`).join("")}</div>`}
function receitaMeta(mes){
 const W=1000,H=270,pl=72,pr=14,pt=14,pb=30,n=12,sl=(W-pl-pr)/n,bw=sl*.55;
 const max=Math.max(1,...mes.map(x=>Math.max(x.rec,x.metaCheia)))/100,teto=nice(max),Y=v=>pt+(H-pt-pb)*(1-v/teto);let g="";
 for(let k=0;k<=4;k++){const v=teto*k/4;g+=`<line x1="${pl}" x2="${W-pr}" y1="${Y(v)}" y2="${Y(v)}" stroke="#E5E7EB"/><text x="${pl-8}" y="${Y(v)+4}" text-anchor="end">${abrevEixo(v)}</text>`}
 let pts=[];
 mes.forEach((x,i)=>{const cx=pl+i*sl+sl/2,y=Y(x.rec/100),y0=Y(0),bx=cx-bw/2;
  g+=`<path d="M${bx},${y0}V${y+4}Q${bx},${y} ${bx+4},${y}H${bx+bw-4}Q${bx+bw},${y} ${bx+bw},${y+4}V${y0}Z" fill="${COR.li}" opacity="${x.no?1:.35}"/>`;
  g+=`<text x="${cx}" y="${H-10}" text-anchor="middle">${MES3[i]}</text>`;pts.push([cx,Y(x.metaCheia/100)]);
  g+=`<rect x="${pl+i*sl}" y="${pt}" width="${sl}" height="${H-pt-pb}" fill="transparent" data-tip="${MESES[i]}|Receita: ${brl(x.rec)}|Meta: ${brl(x.metaCheia)}${x.meta!==x.metaCheia?"|Meta até "+dbr(ULT)+": "+brl(x.meta):""}"/>`});
 g+=`<path d="${pts.map((p,i)=>(i?"L":"M")+p[0]+","+p[1]).join(" ")}" fill="none" stroke="${COR.cmp}" stroke-width="2" stroke-dasharray="4 4"/>`+pts.map(p=>`<circle cx="${p[0]}" cy="${p[1]}" r="3" fill="${COR.cmp}"/>`).join("");
 return `<svg class="graf" viewBox="0 0 ${W} ${H}" role="img" aria-label="Receita contra a meta, mês a mês">${g}</svg><div class="legenda"><span><i style="background:${COR.li}"></i>Receita</span><span><i style="background:${COR.cmp}"></i>Meta do mês (tracejado)</span></div>`}

/* ---------- Resultado ---------- */
function calcRes(meses){
 const ini=iso(Math.min(...meses),1),fim=iso(Math.max(...meses),31),rec=sv(vend(ini,fim)),mp=soma(D.notas.filter(n=>n.d>=ini&&n.d<=fim),"v"),dsp=sd(desp(ini,fim)),orc=orcPer(meses,ULT);
 return {rec,mp,dsp,orc,res:rec-mp-dsp,marg:rec?(rec-mp-dsp)/rec:0}}
function pResultado(){
 const p=periodo(),M=mesesPer(),R=calcRes(M);
 const mes12=[];for(let m=1;m<=12;m++){const c=calcRes([m]);mes12.push(Object.assign({m,no:M.includes(m)},c))}
 const ini=p.ini,fim=p.fim,Dd=desp(ini,fim);
 const cats=DIR.orc.map(o=>{const real=Dd.filter(x=>x[2]===o.categoria).reduce((a,x)=>a+x[4],0),orc=Math.round(orcLinha(o,M,ULT));return {cat:o.categoria,centro:o.centro,real,orc,dif:real-orc,r:orc?real/orc:0}});
 reg("r-cat",cats,[{t:"Categoria",f:r=>`<b>${esc(r.cat)}</b>`,s:r=>r.cat},{t:"Centro de custo",f:r=>esc(r.centro),s:r=>r.centro},{t:"Realizado",d:1,f:r=>brl(r.real),s:r=>r.real},{t:"Orçado",d:1,f:r=>brl(r.orc),s:r=>r.orc},{t:"Diferença",d:1,f:r=>brl(r.dif),s:r=>r.dif},{t:"Realizado ÷ orçado",d:1,f:r=>r.orc?pilulaPct(r.r):"—",s:r=>r.r}],{});
 reg("r-mes",mes12,[{t:"Mês",f:r=>`<b>${MESES[r.m-1]}</b>${r.no?' <span class="pill ok">no período</span>':""}`,s:r=>r.m},{t:"Receita",d:1,f:r=>brl(r.rec),s:r=>r.rec},{t:"Matéria-prima",d:1,f:r=>brl(r.mp),s:r=>r.mp},{t:"Despesas",d:1,f:r=>brl(r.dsp),s:r=>r.dsp},{t:"Resultado",d:1,f:r=>brl(r.res),s:r=>r.res},{t:"Margem",d:1,f:r=>r.rec?pc(r.marg):"—",s:r=>r.marg}],{});
 const parcial=ULT_NOTA&&ULT_NOTA<ULT&&M.some(m=>fracM(m,ULT)>0&&fracM(m,ULT)<1)?`<div class="caixa warn">As notas dos fornecedores vão até ${dbr(ULT_NOTA)} e as vendas até ${dbr(ULT)}. A matéria-prima do último mês pode estar incompleta, e a margem dele, inflada.</div>`:"";
 const dd=R.orc?R.dsp/R.orc:0;
 return `<h1>Resultado · ${esc(p.curto)}</h1><p class="lede">Receita, menos a matéria-prima (as notas dos fornecedores), menos as despesas. O orçamento do mês corrente vale até ${dbr(ULT)}.</p>${parcial}
 ${cartoesGen([{k:"rec",r:"Receita",v:R.rec,c:COR.li},{k:"mp",r:"Matéria-prima",v:R.mp,c:COR.fat,sub:"notas dos fornecedores"},{k:"desp",r:"Despesas",v:R.dsp,c:COR.cmp},{k:"orc",r:"Orçamento de despesas",v:R.orc,c:COR.co,sub:R.orc?pc(dd)+" do orçado":""},{k:"res",r:"Resultado",v:R.res,c:R.res>=0?COR.li:COR.re},{k:"marg",r:"Margem",v:Math.round(R.marg*1e4),c:COR.fat,pct:1,sub:"meta de 18 % da receita"}],"n3")}
 <div class="grade">
  <section class="cartao c12"><h3>Receita e custos, mês a mês</h3><p class="leg">Barras: matéria-prima e despesas empilhadas. Linha verde: receita. Meses do período em destaque.</p>${custosChart(mes12)}</section>
  <section class="cartao c12"><h3>Despesas contra o orçamento</h3><p class="leg">Por categoria, no período</p>${tabela("r-cat",cats,[])}</section>
  <section class="cartao c12"><h3>Mês a mês</h3>${tabela("r-mes",mes12,[])}</section>
 </div>`}
function custosChart(mes){
 const W=1000,H=270,pl=72,pr=14,pt=14,pb=30,n=12,sl=(W-pl-pr)/n,bw=sl*.55;
 const max=Math.max(1,...mes.map(x=>Math.max(x.rec,x.mp+x.dsp)))/100,teto=nice(max),Y=v=>pt+(H-pt-pb)*(1-v/teto);let g="",pts=[];
 for(let k=0;k<=4;k++){const v=teto*k/4;g+=`<line x1="${pl}" x2="${W-pr}" y1="${Y(v)}" y2="${Y(v)}" stroke="#E5E7EB"/><text x="${pl-8}" y="${Y(v)+4}" text-anchor="end">${abrevEixo(v)}</text>`}
 mes.forEach((x,i)=>{const cx=pl+i*sl+sl/2,bx=cx-bw/2,op=x.no?1:.35,y1=Y(x.mp/100),y0=Y(0),y2=Y((x.mp+x.dsp)/100);
  g+=`<rect x="${bx}" y="${y1}" width="${bw}" height="${Math.max(0,y0-y1)}" fill="${COR.fat}" opacity="${op}"/><path d="M${bx},${y1}V${y2+4}Q${bx},${y2} ${bx+4},${y2}H${bx+bw-4}Q${bx+bw},${y2} ${bx+bw},${y2+4}V${y1}Z" fill="${COR.cmp}" opacity="${op}"/>`;
  g+=`<text x="${cx}" y="${H-10}" text-anchor="middle">${MES3[i]}</text>`;pts.push([cx,Y(x.rec/100)]);
  g+=`<rect x="${pl+i*sl}" y="${pt}" width="${sl}" height="${H-pt-pb}" fill="transparent" data-tip="${MESES[i]}|Receita: ${brl(x.rec)}|Matéria-prima: ${brl(x.mp)}|Despesas: ${brl(x.dsp)}|Resultado: ${brl(x.res)}"/>`});
 g+=`<path d="${pts.map((p,i)=>(i?"L":"M")+p[0]+","+p[1]).join(" ")}" fill="none" stroke="${COR.li}" stroke-width="2"/>`+pts.map(p=>`<circle cx="${p[0]}" cy="${p[1]}" r="3" fill="${COR.li}"/>`).join("");
 return `<svg class="graf" viewBox="0 0 ${W} ${H}" role="img" aria-label="Receita e custos, mês a mês">${g}</svg><div class="legenda"><span><i style="background:${COR.fat}"></i>Matéria-prima</span><span><i style="background:${COR.cmp}"></i>Despesas</span><span><i style="background:${COR.li}"></i>Receita</span></div>`}

/* ---------- detalhes (gaveta) ---------- */
function gaveta(html){document.getElementById("gaveta").innerHTML=`<button class="fechar" data-act="fechar" aria-label="Fechar">✕</button>`+html;document.getElementById("veu").style.display="block";const g=document.getElementById("gaveta");g.classList.add("on");g.setAttribute("aria-hidden","false")}
function abrirKR(id){const k=medirKRs(corteKR()).find(x=>x.id===id);if(!k)return;
 gaveta(`<h2>${esc(k.nome)}</h2><div style="color:var(--muted)">${esc(k.obj)} · ${esc(k.resp)}</div><div style="margin:10px 0"><span class="pill ${ESTR[k.est][0]}">${ESTR[k.est][1]}</span></div>
 <dl><dt>Realizado</dt><dd><b>${fk(k,k.valor)}</b></dd><dt>Ritmo esperado</dt><dd>${fk(k,k.ritmo)}</dd><dt>Meta do ano</dt><dd>${k.tipo==="max"?"no máximo ":""}${fk(k,k.meta)}</dd><dt>Data de corte</dt><dd>${dbr(corteKR())}</dd></dl>
 <div class="caixa ${k.est==="ok"?"ok":k.est==="atencao"?"warn":"bad"}"><b>Como foi medido</b><br>${esc(k.como)}</div>
 <p class="leg">Regra do estado: no ritmo quando realizado alcança o ritmo esperado; atenção até 10 % abaixo (ou até 10 % acima do limite); fora além disso.</p>`)}
function abrirItem(tipo,chave){
 const campo={produto:5,canal:3,cliente:2}[tipo],M=mesesPer();
 const rows=DIR.vendas.filter(v=>v[campo]===chave);const linhas=[];
 for(let m=1;m<=12;m++){const x=rows.filter(v=>+v[0].slice(5,7)===m);linhas.push([MESES[m-1],sv(x),x.length,M.includes(m)])}
 gaveta(`<h2>${esc(chave)}</h2><div style="color:var(--muted)">${tipo==="produto"?"Produto":tipo==="canal"?"Canal":"Cliente"} · receita de ${D.ano}, mês a mês</div>${tipo==="produto"?`<img src="${fotoDe(chave)}" alt="" style="width:120px;border-radius:12px;margin-top:12px">`:""}
 <table style="margin-top:14px"><thead><tr><th style="cursor:default">Mês</th><th class="d" style="cursor:default">Notas de saída</th><th class="d" style="cursor:default">Receita</th></tr></thead><tbody>${linhas.map(l=>`<tr style="cursor:default;${l[3]?"background:#F1F5F9":""}"><td>${l[0]}</td><td class="d">${l[2]}</td><td class="d">${brl(l[1])}</td></tr>`).join("")}<tr style="cursor:default"><td><b>Ano</b></td><td class="d"><b>${rows.length}</b></td><td class="d" data-total-item="${sv(rows)}"><b>${brl(sv(rows))}</b></td></tr></tbody></table>`)}
