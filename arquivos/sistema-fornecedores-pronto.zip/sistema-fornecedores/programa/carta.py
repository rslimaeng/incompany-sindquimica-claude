#!/usr/bin/env python3
"""Rascunho da carta ao fornecedor, a partir de documentos-padrao/modelo-carta-ao-fornecedor.docx.
Uso:  python3 programa/carta.py <Fornecedor> <nº da nota> [--prazo DD/MM/AAAA] [--pedimos "texto"]
O rascunho é montado com os números do histórico; quem manda a carta é a coordenação, depois de ler."""
import argparse, datetime as dt, json, re, sys
from pathlib import Path
import docx
sys.path.insert(0, str(Path(__file__).parent))
import leitores as L, cruzar as C

RAIZ = Path(__file__).resolve().parent.parent
MESES = ["janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"]


def brl(c):
    return "R$ " + f"{c / 100:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def num(x):
    return f"{x:,.0f}".replace(",", ".")


def dbr(iso):
    return "/".join(reversed(iso.split("-")))


def carregar(forn, nota):
    notas = json.loads((RAIZ / "historico" / "notas.json").read_text(encoding="utf-8"))
    laudos = json.loads((RAIZ / "historico" / "laudos.json").read_text(encoding="utf-8"))
    res = C.cruzar(notas, laudos, C.ler_pedidos(RAIZ), C.ler_specs(RAIZ))
    r = next((x for x in res if L.norm(x["fornecedor"]) == L.norm(forn) and x["nota"] == str(nota)), None)
    if not r:
        sys.exit("Não achei a nota %s da %s no histórico." % (nota, forn))
    cad = next(v for k, v in C.ler_fornecedores(RAIZ).items() if L.norm(k) == L.norm(forn))
    return r, cad, laudos.get(r["lote"])


def redigir(r, laudos):
    """-> (divergência, o que encontramos, o que fizemos, o que pedimos)"""
    q = r["qtd_kg"]
    base = "a nota refere-se a %s kg de %s (lote %s), no valor de %s" % (num(q), r["produto"], r["lote"], brl(r["valor_c"]))
    if r["status"] == "bloqueado":
        obs = (", e traz a observação «%s»" % r["obs"]) if r["obs"] and not r["obs"].startswith("(") else ""
        enc = "%s%s. Não há, no nosso cadastro, pedido de compra que corresponda a esse lote%s, e não localizamos registro de recebimento desse material." % (base, obs, "")
        if not laudos:
            enc += " O lote também não veio acompanhado de laudo."
        return ("ausência de pedido de compra", enc,
                "Por isso, a nota está bloqueada: não será paga até que o nosso setor de Suprimentos confirme a compra.",
                "o nome de quem autorizou a entrega e a data dessa autorização, o pedido ou a confirmação por escrito que a sustenta" + (", e o laudo do lote %s" % r["lote"] if not laudos else ""))
    if r["status"] == "retido":
        mot = [m for m in r["motivos"] if not m.startswith(("preço", "faturado"))]
        enc = "%s. O laudo do lote não atende à nossa especificação: %s." % (base, "; ".join(mot) or "sem laudo")
        return ("lote fora da especificação" if laudos else "lote sem laudo", enc,
                "Por isso, o pagamento desta nota está retido até a nossa área de Qualidade decidir sobre o lote.",
                "um novo laudo do lote, ou a carta de correção, ou o plano de ação para o lote")
    if r["preco_nota"] and r["preco_pedido"] and r["cobrado_c"] and r["preco_nota"] / r["preco_pedido"] - 1 > 0.02 + 1e-9:
        enc = "%s. O pedido %s previa R$ %s por kg; a nota cobra R$ %s por kg, acima da nossa tolerância de 2 %%." % (
            base, r["pedido"], f"{r['preco_pedido']:.2f}".replace(".", ","), f"{r['preco_nota']:.2f}".replace(".", ","))
        return ("preço acima do pedido", enc, "Por isso, pagaremos o valor do pedido, %s, e a diferença de %s fica como cobrança." % (brl(r["a_pagar_c"]), brl(r["cobrado_c"])),
                "uma nota de crédito ou carta de correção de %s" % brl(r["cobrado_c"]))
    if r["cobrado_c"]:
        enc = "%s. O almoxarifado recebeu %s kg, e a nota fatura %s kg." % (base, num(r["qtd_recebida"]), num(q))
        return ("quantidade faturada acima da recebida", enc, "Por isso, pagaremos apenas o que foi recebido, %s, e a diferença de %s fica como cobrança." % (brl(r["a_pagar_c"]), brl(r["cobrado_c"])),
                "uma nota de crédito ou carta de correção de %s" % brl(r["cobrado_c"]))
    sys.exit("A nota %s não tem divergência: não há carta a escrever." % r["nota"])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("fornecedor"); ap.add_argument("nota")
    ap.add_argument("--prazo"); ap.add_argument("--pedimos"); ap.add_argument("--saida")
    a = ap.parse_args()
    r, cad, laudos = carregar(a.fornecedor, a.nota)
    hoje = dt.date.today()
    prazo = a.prazo or (hoje + dt.timedelta(days=7)).strftime("%d/%m/%Y")
    dv, enc, fiz, ped = redigir(r, laudos)
    d = docx.Document(RAIZ / "documentos-padrao" / "modelo-carta-ao-fornecedor.docx")
    P = d.paragraphs
    contato = cad["contato"]
    novos = {
        1: "Fortaleza, %d de %s de %d" % (hoje.day, MESES[hoje.month - 1], hoje.year),
        2: "À %s\nA/C %s" % (cad["razao"], contato),
        3: "Assunto: %s na nota fiscal %s, lote %s" % (dv, r["nota"], r["lote"]),
        4: "Prezado(a) %s," % contato,
        5: "Na conferência da nota fiscal %s, de %s, encontramos: %s" % (r["nota"], dbr(r["data"]), enc),
        6: fiz,
        7: "Pedimos %s até %s." % (a.pedimos or ped, prazo),
    }
    for i, t in novos.items():
        P[i].runs[0].text = t
        for extra in P[i].runs[1:]:
            extra.text = ""
    resto = [p.text for p in P if "[" in p.text and "]" in p.text]
    out = Path(a.saida) if a.saida else RAIZ / "cartas" / ("carta-%s-nf%s.docx" % (L.norm(a.fornecedor).replace(" ", "-"), r["nota"]))
    out.parent.mkdir(exist_ok=True)
    d.save(out)
    print("Carta salva em", out.relative_to(RAIZ))
    print("Prazo usado: %s (%s)" % (prazo, "informado" if a.prazo else "sugestão de 7 dias: confirmar"))
    if resto:
        print("ATENÇÃO, sobrou campo do modelo sem preencher:", resto)
    print("\n" + "\n\n".join(novos[i] for i in sorted(novos)))


if __name__ == "__main__":
    main()
