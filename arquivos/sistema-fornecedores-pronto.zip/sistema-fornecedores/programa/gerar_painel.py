"""Monta o painel.html: um arquivo só, com os dados, o logo e as fotos dentro. Abre com dois cliques, sem internet."""
import base64, io, json, unicodedata
from pathlib import Path
from PIL import Image, ImageChops


def _recortar(im, margem=8):
    fundo = Image.new(im.mode, im.size, (255, 255, 255, 255) if im.mode == "RGBA" else (255, 255, 255))
    base = im.convert("RGBA")
    chapado = Image.new("RGBA", base.size, (255, 255, 255, 255)); chapado.alpha_composite(base)
    dif = ImageChops.difference(chapado.convert("RGB"), Image.new("RGB", base.size, (255, 255, 255)))
    box = dif.point(lambda v: 255 if v > 12 else 0).getbbox()
    if not box:
        return im
    x0, y0, x1, y1 = box
    return chapado.convert("RGB").crop((max(0, x0 - margem), max(0, y0 - margem), min(base.width, x1 + margem), min(base.height, y1 + margem)))


def _png(path, largura, recortar=True):
    im = Image.open(path)
    im = _recortar(im) if recortar else im.convert("RGB")
    im.thumbnail((largura, largura))
    b = io.BytesIO(); im.save(b, "PNG", optimize=True)
    return "data:image/png;base64," + base64.b64encode(b.getvalue()).decode()


def _jpg(path, largura=900):
    im = Image.open(path).convert("RGB")
    im.thumbnail((largura, largura))
    b = io.BytesIO(); im.save(b, "JPEG", quality=78, optimize=True)
    return "data:image/jpeg;base64," + base64.b64encode(b.getvalue()).decode()


def gerar(raiz, resultados, repetidas, fornecedores, agora, conferencia, diretoria=None):
    raiz = Path(raiz)
    forn = []
    for nome, f in fornecedores.items():
        forn.append({"id": "".join(c for c in unicodedata.normalize("NFD", nome) if unicodedata.category(c) != "Mn").lower(), "nome": nome, "razao": f["razao"], "cidade": f["cidade"], "contato": f["contato"], "email": f["email"],
                     "prazo": f["prazo"], "materias": f["materias"],
                     "logo": _png(raiz / "fornecedores" / f["logo"], 260), "foto": _jpg(raiz / "fornecedores" / f["foto"])})
    notas = []
    for r in resultados:
        notas.append({"f": r["fornecedor"].lower(), "n": r["nota"], "d": r["data"], "ped": r["pedido"], "pc": r["pedido_citado"], "p": r["produto"], "l": r["lote"],
                      "q": r["qtd_kg"], "qr": r["qtd_recebida"], "pn": r["preco_nota"], "pp": r["preco_pedido"], "v": r["valor_c"], "ap": r["a_pagar_c"],
                      "li": r["liberado_c"], "re": r["retido_c"], "bl": r["bloqueado_c"], "co": r["cobrado_c"], "s": r["status"],
                      "m": r["motivos"], "a": r["acoes"], "arq": r["arquivo"], "ql": r["qualidade"]})
    notas.sort(key=lambda n: (n["d"], n["f"], n["n"]))
    dados = {"gerado": agora.strftime("%d/%m/%Y, %Hh%M"), "ano": 2026,
             "logo": _png(raiz / "identidade-visual" / "logo-serra-azul.png", 520),
             "forn": forn, "notas": notas, "repetidas": repetidas, "conferencia": conferencia}
    if diretoria and diretoria["vendas"]:
        P = diretoria["plan"]
        fotos = {}
        for f in sorted((raiz / "produtos").glob("*.png")):
            fotos[f.stem] = _jpg(f, 260)
        dados["dir"] = {
            "vendas": [[v["data"], v["nf"], v["cliente"], v["canal"], v["codigo"], v["produto"], v["qtd"], v["preco"], int(round(v["valor"] * 100))] for v in sorted(diretoria["vendas"], key=lambda x: (x["data"], str(x["nf"])))],
            "despesas": [[d["data"], d["centro"], d["categoria"], d["descricao"], int(round(d["valor"] * 100))] for d in sorted(diretoria["despesas"], key=lambda x: (x["data"], x["categoria"]))],
            "repetidas": diretoria["rep"],
            "okrs": P["okrs"], "meta": P["meta_receita"], "clientes2025": P["clientes_2025"],
            "orc": [{"categoria": o["categoria"], "centro": o["centro"], "meses": [int(round(x * 100)) for x in o["meses"]]} for o in P["orcamento"]],
            "fotos": fotos}
    html = (Path(__file__).parent / "painel.template.html").read_text(encoding="utf-8")
    js = json.dumps(dados, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")
    html = html.replace("/*DADOS*//*FIM*/", "/*DADOS*/" + js + "/*FIM*/")
    (raiz / "painel.html").write_text(html, encoding="utf-8")
    return raiz / "painel.html"
