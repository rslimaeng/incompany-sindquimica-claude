"""Lê planejamento/planejamento-estrategico-2026.xlsx (OKRs, metas de receita, clientes de 2025, orçamento)."""
from pathlib import Path
import openpyxl
import leitores as L

MESES = ["janeiro", "fevereiro", "marco", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"]


def ler_planejamento(raiz):
    wb = openpyxl.load_workbook(Path(raiz) / "planejamento" / "planejamento-estrategico-2026.xlsx", data_only=True)
    ab = {L.norm(ws.title): ws for ws in wb.worksheets}
    okrs = []
    for l in list(ab["okrs"].iter_rows(values_only=True))[1:]:
        if l[0]:
            okrs.append({"objetivo": l[0], "kr": l[1], "como": l[2], "meta": float(l[3]), "unidade": l[4], "resp": l[5], "fonte": l[6]})
    meta = [0.0] * 12
    for l in list(ab["metas de receita"].iter_rows(values_only=True))[1:]:
        k = L.norm(str(l[0]))
        if k in MESES:
            meta[MESES.index(k)] = float(l[1])
    clientes = [{"cliente": l[0], "canal": l[1]} for l in list(ab["clientes em 2025"].iter_rows(values_only=True))[1:] if l[0]]
    orc = []
    for l in list(ab["orcamento de despesas"].iter_rows(values_only=True))[1:]:
        if l[0]:
            orc.append({"categoria": l[0], "centro": l[1], "meses": [float(x) for x in l[2:14]]})
    return {"okrs": okrs, "meta_receita": meta, "clientes_2025": clientes, "orcamento": orc}
