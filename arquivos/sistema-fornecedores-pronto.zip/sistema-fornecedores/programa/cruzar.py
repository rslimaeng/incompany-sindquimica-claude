"""Cruza nota x pedido x laudo e aplica as regras do CLAUDE.md. Tudo em centavos (inteiros) para a soma fechar."""
import re
from pathlib import Path
import openpyxl
import leitores as L

TOLERANCIA_PRECO = 0.02  # regra 1: até 2 % acima do pedido, paga a nota


# ------------------------------------------------------------------ cadastros
def ler_pedidos(pasta):
    wb = openpyxl.load_workbook(Path(pasta) / "cadastros" / "pedidos-de-compra.xlsx", data_only=True)
    ws = wb["Pedidos"]
    linhas = list(ws.iter_rows(values_only=True))
    cab = [L.norm(c) for c in linhas[0]]
    col = lambda rx: next(i for i, c in enumerate(cab) if re.search(rx, c))
    ix = dict(num=col(r"n. pedido"), forn=col(r"fornecedor"), cod=col(r"cod. mp"), mp=col(r"materia-prima"),
              qped=col(r"qtd pedida"), preco=col(r"preco acordado"), lote=col(r"lote recebido"),
              qrec=col(r"qtd recebida"), drec=col(r"data de recebimento"))
    pedidos = {}
    for l in linhas[1:]:
        if not l[ix["num"]]:
            continue
        pedidos[l[ix["num"]]] = {
            "pedido": l[ix["num"]], "fornecedor": l[ix["forn"]], "cod_mp": l[ix["cod"]], "mp": l[ix["mp"]],
            "qtd_pedida": float(l[ix["qped"]]), "preco": float(l[ix["preco"]]), "lote": L.lote_norm(l[ix["lote"]]),
            "qtd_recebida": float(l[ix["qrec"]]) if l[ix["qrec"]] is not None else None,
            "data_recebimento": l[ix["drec"]].date().isoformat() if l[ix["drec"]] else None}
    return pedidos


def interpretar_spec(txt):
    """'≥ 96,0' | 'máx. 1,5' | '40 max' | '26,0 a 28,0' | '6,5 – 8,5' | 'mín. 10,0 / máx. 12,5' -> (min, max)."""
    s = str(txt).strip().lower()
    nums = [float(x.replace(",", ".")) for x in re.findall(r"\d+(?:,\d+)?", s)]
    if len(nums) == 2 and re.search(r"\d\s*(a|–|-|—)\s*\d", s):
        return min(nums), max(nums)
    if len(nums) == 2 and "mín" in s.replace("min", "mín") and "máx" in s.replace("max", "máx"):
        return nums[0], nums[1]
    if len(nums) == 1:
        if re.search(r"≥|>=|mín|min", s):
            return nums[0], None
        if re.search(r"≤|<=|máx|max", s):
            return None, nums[0]
    raise ValueError("não entendi a especificação: %r" % txt)


def ler_specs(pasta):
    ws = openpyxl.load_workbook(Path(pasta) / "cadastros" / "especificacoes-materia-prima.xlsx", data_only=True).active
    specs = {}  # nome normalizado da MP -> {param normalizado: dict}
    for l in list(ws.iter_rows(values_only=True))[1:]:
        if not l[0]:
            continue
        lo, hi = interpretar_spec(l[3])
        specs.setdefault(L.norm(l[1]), {"cod": l[0], "nome": l[1], "params": {}})["params"][L.norm(l[2])] = {
            "nome": l[2], "texto": l[3], "min": lo, "max": hi, "unidade": l[4]}
    return specs


def ler_fornecedores(pasta):
    ws = openpyxl.load_workbook(Path(pasta) / "fornecedores" / "cadastro-fornecedores.xlsx", data_only=True).active
    out = {}
    for l in list(ws.iter_rows(values_only=True))[1:]:
        if l[0]:
            out[l[0]] = {"nome": l[0], "razao": l[1], "cidade": l[2], "contato": l[3], "email": l[4], "prazo": l[5],
                         "materias": l[6], "logo": l[7], "foto": l[8]}
    return out


# ------------------------------------------------------------------ qualidade
def _br(x):
    return str(x).replace(".", ",")


def _un(u):
    u = (u or "").lower().replace(" ", "")
    return {"ppm": "mg/kg"}.get(u, u)


def avaliar_lote(produto_nome, params_laudo, specs):
    """-> (situacao, [motivos]); situacao: 'conforme' | 'fora' | 'sem_spec' | 'sem_laudo'"""
    sp = specs.get(L.norm(produto_nome or ""))
    if sp is None:
        return "sem_spec", ["matéria-prima %r sem especificação cadastrada" % produto_nome]
    if not params_laudo:
        return "sem_laudo", ["lote sem laudo"]
    motivos, fora = [], False
    vistos = set()
    for p in params_laudo:
        k = L.norm(p["parametro"])
        spec = sp["params"].get(k)
        if spec is None:
            motivos.append("parâmetro %r do laudo sem especificação cadastrada" % p["parametro"]); fora = True
            continue
        vistos.add(k)
        if p["valor"] is None:
            motivos.append("%s: resultado ilegível (%s)" % (p["parametro"], p["bruto"])); fora = True
            continue
        if p["op"] == "<":  # regra 3: "<0,05" é conforme
            continue
        if spec["unidade"] and p["unidade"] and _un(spec["unidade"]) != _un(p["unidade"]):
            motivos.append("%s: unidade do laudo (%s) diferente da especificação (%s)" % (p["parametro"], p["unidade"], spec["unidade"])); fora = True
            continue
        v, lo, hi = p["valor"], spec["min"], spec["max"]
        eps = 1e-9
        if lo is not None and v < lo - eps:
            motivos.append("%s %s abaixo do mínimo (%s)" % (p["parametro"], _br(p["bruto"]), spec["texto"])); fora = True
        if hi is not None and v > hi + eps:
            motivos.append("%s %s acima do máximo (%s)" % (p["parametro"], _br(p["bruto"]), spec["texto"])); fora = True
    faltam = [s["nome"] for k, s in sp["params"].items() if k not in vistos]
    if faltam:
        motivos.append("laudo sem: " + ", ".join(faltam)); fora = True
    return ("fora" if fora else "conforme"), motivos


# ------------------------------------------------------------------ cruzamento
def cents(x):
    return int(round(x * 100))


def cruzar(notas, laudos_por_lote, pedidos, specs):
    por_lote = {}
    for p in pedidos.values():
        if p["lote"]:
            por_lote.setdefault(p["lote"], []).append(p)
    out = []
    for n in notas:
        r = dict(n)
        motivos, acoes = [], []
        v = cents(n["valor"])
        ped = None
        cands = por_lote.get(n["lote"], [])
        if len(cands) == 1:
            ped = cands[0]
        elif len(cands) > 1:
            ped = next((c for c in cands if c["pedido"] == n["pedido_citado"]), cands[0])
            motivos.append("lote em mais de um pedido")
        q_fat = n["qtd_kg"]
        preco_nota = n["preco_nota"] if n["preco_nota"] else (n["valor"] / q_fat if q_fat else None)
        if n["preco_nota"] and q_fat and abs(n["preco_nota"] * q_fat - n["valor"]) > 0.5:
            motivos.append("conta da nota não fecha: %s kg × R$ %s ≠ R$ %s" % (q_fat, n["preco_nota"], n["valor"]))
        r["qualidade"] = "n/a"
        r.update(pedido=ped["pedido"] if ped else None, preco_nota=preco_nota, preco_pedido=ped["preco"] if ped else None,
                 qtd_recebida=ped["qtd_recebida"] if ped else None, qtd_pedida=ped["qtd_pedida"] if ped else None,
                 valor_c=v)
        if ped is None:
            r.update(status="bloqueado", a_pagar_c=0, liberado_c=0, retido_c=0, bloqueado_c=v, cobrado_c=0, qualidade="n/a")
            citou = n["pedido_citado"]
            motivos.append("nota sem pedido" + (" (cita %s, mas o lote não consta nele)" % citou if citou else (" (%s)" % (n["obs"] or "nenhum pedido citado")) if not (n["obs"] or n["texto_pedido"] or "").startswith("(") else ""))
            acoes.append("Suprimentos confirmar se a compra existe; pagamento bloqueado")
            if not laudos_por_lote.get(n["lote"]):
                motivos.append("o lote %s também está sem laudo" % n["lote"])
        else:
            if n["pedido_citado"] and n["pedido_citado"] != ped["pedido"]:
                motivos.append("nota cita %s, mas o lote está no pedido %s" % (n["pedido_citado"], ped["pedido"]))
            excesso = preco_nota / ped["preco"] - 1
            if excesso > TOLERANCIA_PRECO + 1e-9:
                preco_pago = ped["preco"]
                motivos.append("preço %s %% acima do pedido (R$ %s contra R$ %s por kg)" % (f"{excesso * 100:.1f}".replace(".", ","), f"{preco_nota:.2f}".replace(".", ","), f"{ped['preco']:.2f}".replace(".", ",")))
            else:
                preco_pago = preco_nota
                if excesso > 1e-9:
                    motivos.append("preço %s %% acima do pedido, dentro dos 2 %%: pago a nota" % f"{excesso * 100:.1f}".replace(".", ","))
            q_pago = min(q_fat, ped["qtd_recebida"])
            if q_fat > ped["qtd_recebida"] + 1e-9:
                motivos.append("faturado %s kg, recebido %s kg" % (f"{q_fat:,.0f}".replace(",", "."), f"{ped['qtd_recebida']:,.0f}".replace(",", ".")))
            ap = cents(q_pago * preco_pago)
            ap = min(ap, v)
            qual, mq = avaliar_lote(ped["mp"], laudos_por_lote.get(n["lote"]), specs)
            r["qualidade"] = qual
            if qual == "conforme":
                r.update(status="liberado", liberado_c=ap, retido_c=0)
            else:
                r.update(status="retido", liberado_c=0, retido_c=ap)
                motivos += mq
                acoes.append("Qualidade decidir sobre o lote %s" % n["lote"])
            r.update(a_pagar_c=ap, bloqueado_c=0, cobrado_c=v - ap)
            if v - ap > 0:
                acoes.append("Cobrar do fornecedor R$ %s" % f"{(v - ap) / 100:,.2f}".replace(",", "X").replace(".", ",").replace("X", "."))
            if r["status"] == "liberado":
                acoes.insert(0, "Liberar R$ %s para o financeiro" % f"{ap / 100:,.2f}".replace(",", "X").replace(".", ",").replace("X", "."))
        r["motivos"] = motivos
        r["acoes"] = acoes
        assert r["valor_c"] == r["liberado_c"] + r["retido_c"] + r["bloqueado_c"] + r["cobrado_c"], r
        out.append(r)
    return out
