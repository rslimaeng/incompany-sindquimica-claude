---
name: atualizar-painel
description: Atualiza o painel (pagamento de fornecedores e visão da diretoria) quando chegam arquivos novos. Use quando o usuário disser "leia os novos arquivos", "chegaram os arquivos de <mês>", "atualize o painel", ou quando houver arquivos em novos-arquivos/. Lê as notas e os laudos dos 5 fornecedores, as vendas e as despesas, cruza com pedidos, especificações e planejamento, refaz o painel.html, roda a conferência e atualiza o 00-aqui-paramos.md.
---

# Atualizar o painel

Rode este roteiro **inteiro**, na ordem. A frase do usuário é só: **"leia os novos arquivos"**.

## 1. Ver o que chegou

- Liste `novos-arquivos/` (nome e tamanho). O esperado é, por fornecedor (Aromas, Brisamar, Carnauba, Polar, Quimisol), **um arquivo de notas e um de laudos**, mais **um arquivo `Vendas …` e um `Despesas …`** do mesmo período.
- Arquivo com **outro nome** (não fornecedor, não Vendas, não Despesas) o programa não lê e deixa em `novos-arquivos/`: **não leia, não mova, não apague**, avise o usuário.
- Diga em uma linha quantos arquivos chegaram e **quais faltam**. Faltar um não impede de seguir: diga o que ficará sem cruzar (nota sem laudo fica retida).
- Se não houver nada, diga isso e pare: o painel já está atualizado até `00-aqui-paramos.md`.

## 2. Rodar o programa

```
python3 programa/atualizar.py
```

Ele lê cada arquivo pelo **cabeçalho** (as vendas e as despesas guardam em `historico/vendas.json` e `historico/despesas.json`; o planejamento e os cadastros são relidos a cada rodada), cruza nota × pedido × laudo pelas regras do `CLAUDE.md`, guarda o histórico em `historico/`, **move os arquivos lidos para `arquivos-lidos/`** e refaz `painel.html` e `conferencia.txt`. Uma nota que já está no histórico (mesmo fornecedor e número) **não entra de novo**: o programa lista como "repetida".

## 3. Se alguma linha começar com "NÃO LI"

O formato daquele arquivo mudou. **Não apague nem edite o arquivo.** Abra-o, leia as primeiras 10 a 25 linhas, ache o que mudou (nome de coluna, aba nova, unidade, formato de data) e ajuste **só o leitor** em `programa/leitores.py`, no menor trecho possível. Rode de novo. Conte ao usuário o que mudou no formato.
Se o ajuste mudar uma **regra** (e não só a leitura), pare e pergunte.

## 4. Conferir (obrigatório)

- A conferência sai no final do programa. **Só entregue se disser "o total da tela bate com o dos arquivos, e cada nota aparece uma vez só".** Se não bater, ache a diferença antes de seguir; não arredonde, não force.
- Rode também `python3 programa/testar_painel.py` (clica em todos os botões do painel no Chrome sem tela). Tem de dar 0 falhas.
- A conferência inclui **a receita da tela contra o arquivo de vendas e as despesas da tela contra o arquivo de despesas** (total e mês a mês). Venda repetida = mesma NF de saída; despesa repetida = mesma data, categoria, descrição e valor.
- Pedidos de compra e especificações (`cadastros/`) são lidos de novo a cada rodada: se o usuário atualizou esses arquivos, o painel reflete.

## 5. Dizer ao usuário, nesta ordem

1. Quantos arquivos e quantas notas novas entraram (e as repetidas, que ficaram de fora).
2. Os números do período novo: faturado, liberado, retido, bloqueado, cobrado a mais, e o acumulado do ano.
3. **O que há de novo para decidir**: cada nota retida, bloqueada ou com cobrança, com fornecedor, número, valor e motivo. Nota que já estava retida e agora tem laudo é dita também.
4. O resultado da conferência, lado a lado, por fornecedor.
5. **A visão da diretoria**: receita, meta do período, matéria-prima, despesas, orçamento, resultado e margem do período novo e do ano (as contas estão no `CLAUDE.md`, seção "A visão da diretoria"), e **quais resultados-chave mudaram de estado** (no ritmo, atenção, fora do ritmo) desde o `00-aqui-paramos.md` anterior.
6. **Dado incompleto:** se as notas dos fornecedores terminam antes das vendas (ex.: notas até 18/11, vendas até 25/11), diga que a matéria-prima e a margem do último mês estão incompletas.
7. Se for o caso, o que **não** foi possível conferir.

Quem decide é o usuário (coordenação de suprimentos). O programa nunca paga, nunca escreve ao fornecedor e nunca apaga nada.

## 6. Encerrar atualizando o `00-aqui-paramos.md` (obrigatório)

Reescreva o arquivo com: a data e a hora; até que data há notas; os arquivos lidos nesta rodada; os números do acumulado e da visão da diretoria (receita, resultado, margem, OKRs); o que ficou **pendente de decisão** (as notas acima); o que mudou de formato ou de regra; e a frase para a próxima vez. **Toda atualização termina aqui.**

## Não faça

- Não edite `historico/` à mão. Ele se refaz lendo os arquivos.
- Não mova arquivos para fora de `arquivos-lidos/` e não apague nada de `novos-arquivos/` ou `arquivos-lidos/`.
- Não mude o padrão visual: ele mora em `identidade-visual/design-system-serra-azul.md`.
