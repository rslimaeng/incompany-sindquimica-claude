---
name: resumo-do-mes
description: Escreve o resumo mensal de pagamento de fornecedores para a diretoria da Química Serra Azul, em uma página. Use quando o usuário pedir "resumo do mês", "resumo para a diretoria", "fechamento de <mês>" ou "como foi outubro". Usa só os números do histórico e do painel, nunca números de memória.
---

# Resumo do mês para a diretoria

1. **Escolha o mês** (`AAAA-MM`). Se o usuário não disse, use o último mês com notas e diga qual.
2. **Tire os números do histórico**, não de memória:
   ```
   python3 programa/resumo.py AAAA-MM
   ```
   Ele grava `resumos/numeros-AAAA-MM.md`: faturado, liberado, retido, bloqueado, cobrado a mais, por fornecedor, e as notas que pedem decisão.
3. **Confira** que o faturado do mês bate com o painel (botão do mês). Se o `programa/conferir.py` não disser "bate", não escreva o resumo.
4. **Escreva `resumos/resumo-AAAA-MM.md`**, em **uma página**, nesta ordem:
   1. **A frase do mês**: quanto foi faturado e quanto está liberado para pagar, em uma linha.
   2. **Os cinco números**: faturado, liberado, retido, bloqueado, cobrado a mais (com variação contra o mês anterior, quando houver).
   3. **O que pede decisão da diretoria**: só o que é de valor ou de risco (nota sem pedido, lote retido, cobranças), cada item com fornecedor, nota, valor e o que se propõe.
   4. **Quem pesa mais**: o fornecedor com maior valor em pendência e com maior valor cobrado a mais.
   5. **O que ficou de fora**: o que não foi possível conferir.
5. Português simples, sem jargão de sistema; valores em `R$ 1.234,56`. **Não invente causa**: se o motivo de um problema não está nos arquivos, escreva "motivo não informado".
6. Diga ao usuário o caminho do arquivo. **Não envie** a ninguém.
