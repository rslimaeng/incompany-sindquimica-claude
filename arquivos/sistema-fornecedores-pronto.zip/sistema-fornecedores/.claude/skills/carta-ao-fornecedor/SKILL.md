---
name: carta-ao-fornecedor
description: Escreve a carta da Química Serra Azul ao fornecedor sobre uma nota com problema (nota sem pedido, preço acima do pedido, quantidade acima da recebida, lote fora da especificação ou sem laudo). Use quando o usuário pedir "escreva a carta à <fornecedor> sobre a nota <número>", "cobrar o fornecedor" ou "carta de divergência". Parte do modelo em documentos-padrao/modelo-carta-ao-fornecedor.docx e entrega um .docx em cartas/.
---

# Carta ao fornecedor

Parte **sempre** do modelo `documentos-padrao/modelo-carta-ao-fornecedor.docx`. Nunca monte a carta do zero.

## Passo a passo

1. **Ache a nota** no histórico (fornecedor + número). Se o usuário não deu o número, use o painel (`O que fazer`) e pergunte qual, se houver mais de uma.
   - Se a nota **não tem problema**, diga isso e não escreva carta.
2. **Confira os fatos antes de escrever**, nos arquivos, não na memória: abra `historico/notas.json` e, para o pedido, o laudo e o recebimento, `cadastros/pedidos-de-compra.xlsx` e `historico/laudos.json`. A carta cita números: pedido, nota, laudo ou recebimento.
3. **Gere o rascunho** com o programa, que preenche o modelo com os números do histórico:
   ```
   python3 programa/carta.py <Fornecedor> <nº da nota> [--prazo DD/MM/AAAA] [--pedimos "texto"]
   ```
   O arquivo sai em `cartas/carta-<fornecedor>-nf<nº>.docx`.
4. **Leia o texto que o programa imprimiu** e ajuste o que for preciso (`--pedimos`, `--prazo`). A carta tem de ter: o que diz o pedido, o que diz a nota, o que diz o laudo ou o recebimento; o que a empresa fez (retido, vai pagar o valor do pedido, bloqueada); e o que pede, com prazo.
5. **Prazo:** se o usuário não disse, o programa sugere 7 dias. **Diga ao usuário que o prazo é sugestão** e peça a confirmação.
6. Confira o `.docx`: nenhum campo `[entre colchetes]` do modelo pode sobrar. Se sobrar, o programa avisa.

## Tom

Educado, direto, sem acusar. Frases curtas. Números em reais no formato `R$ 1.234,56`, datas `19/08/2026`. A carta **não é enviada por você**: o usuário lê, ajusta e manda. Nunca diga que a carta foi enviada.

## Regras do `CLAUDE.md` que a carta repete

Preço até 2 % acima: paga a nota. Acima: paga o do pedido e cobra a diferença. Paga a quantidade recebida. Nota sem pedido: bloqueada até suprimentos confirmar. Lote fora da especificação, sem especificação ou sem laudo: pagamento retido até a qualidade decidir.
